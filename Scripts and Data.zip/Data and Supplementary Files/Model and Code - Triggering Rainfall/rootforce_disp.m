%return bundle pullout force for given displacement
function[PR_u,PR_w,PR_l]=rootforce_disp(disp,kappa,lambda,Wo,meanF_u,meanF_w,meanF_l,Fa,Fb,mF,kF,muF,sigF)

%kappa=0.4;
% disp=0.01;
x=disp;

%% Uniform

if kappa==1
    
    if x<(1/Wo)
        PR_u=Wo*meanF_u*x;
    else
        PR_u=0;
    end
    
elseif kappa==-1/lambda

    if x<((Fa^((lambda+1)/lambda))/Wo)
        PR_u=(Wo*x/lamdba)*(log(Fb)-log(Fa))/((Fb^(1/lambda))-(Fa^(1/lambda)));
    elseif and(x>=((Fa^((lambda+1)/lambda))/Wo),x<((Fb^((lambda+1)/lambda))/Wo))
        PR_u=(Wo*x/(lamdba+1))*(log(Wo*x)-log(Fa))/((Fb^(1/lambda))-(Fa^(1/lambda)));
    elseif x>=((Fb^((lambda+1)/lambda))/Wo)
        PR_u=0;
    end

elseif kappa<1
    
    if x<((Fa^(1-kappa))/Wo)
        PR_u=(Wo*x/(1+kappa*lambda))*((Fb^((1+kappa*lambda)/lambda))-(Fa^((1+kappa*lambda)/lambda)))/((Fb^(1/lambda))-(Fa^(1/lambda)));
    elseif and(x>=((Fa^(1-kappa))/Wo),x<((Fb^(1-kappa))/Wo))
        PR_u=(Wo*x/(1+kappa*lambda))*((Fb^((1+kappa*lambda)/lambda))-((Wo*x)^((1+kappa*lambda)/(lambda-kappa*lambda))))/((Fb^(1/lambda))-(Fa^(1/lambda)));
    elseif x>=((Fb^(1-kappa))/Wo)
        PR_u=0;
    end
    
elseif kappa>1 
    
    if x<((Fa^(1-kappa))/Wo)
        PR_u=(Wo*x/(1+kappa*lambda))*((Fb^((1+kappa*lambda)/lambda))-(Fa^((1+kappa*lambda)/lambda)))/((Fb^(1/lambda))-(Fa^(1/lambda)));
    elseif and(x>=((Fb^(1-kappa))/Wo),x<((Fa^(1-kappa))/Wo))
        PR_u=(Wo*x/(1+kappa*lambda))*(((Wo*x)^((1+kappa*lambda)/(lambda-kappa*lambda)))-(Fb^((1+kappa*lambda)/lambda)))/((Fb^(1/lambda))-(Fa^(1/lambda)));
    elseif x>=((Fa^(1-kappa))/Wo)
        PR_u=0;
    end
    
end


%% Weibull

if kappa==1
    
    if x<(1/Wo)
        PR_w=Wo*meanF_w*x;
    else
        PR_w=0;
    end
    
elseif kappa<1
        
        PR_w=Wo*(kF^kappa)*x*gammainc(((Wo*x)^(mF/(1-kappa)))/(kF^mF),(kappa/mF)+1,'upper');

elseif kappa>1
    

        PR_w=Wo*(kF^kappa)*x*gammainc(((Wo*x)^(mF/(1-kappa)))/(kF^mF),(kappa/mF)+1,'lower');
end


%% Lognormal

if kappa==1
    
    if x<(1/Wo)
        PR_l=Wo*meanF_l*x;
    else
        PR_l=0;
    end
    
elseif kappa<1

    PR_l=0.5*Wo*x*exp(0.5*(kappa^2)*(sigF^2)+kappa*muF)*(1+erf((kappa*(sigF^2)+muF-log(((Wo*x))^(1/(1-kappa))))/(sigF*sqrt(2))));
    
elseif kappa>1
    
    PR_l=0.5*Wo*x*exp(0.5*(kappa^2)*(sigF^2)+kappa*muF)*(1-erf((kappa*(sigF^2)+muF-log(((Wo*x))^(1/(1-kappa))))/(sigF*sqrt(2))));
    
end




