function[Qyield]=yield_function_script_rainfall_v2(Ho,layers,gamma,gamma_w,phi,coh,beta_slope,kh,U)

gamma=mean(gamma);

% %Soil and Geometric Parameters
% Ho=1;
% gamma=20;
% phi=31;
% coh=0;
% betamax=45;

% %seismic parameters
%kh=0.2;

% %Unsaturated Parameters
% n=3.177;
% m=1-(1/n);
% alfa=9.81*0.0352; 9.81*(10^-1.453); %1/m %%%%%%%%%%%%%%CHECK UNITS
% sat=0.375;
% res=0.053;
% gamma_w=9.81; %kN/m
% ksat=2.808*0.000417; %m/hour
% 
% layers=100;
% dz=ones(layers,1);
% layer=(1:1:layers)';
% z=linspace(0,Ho,layers)';
% hbase=1.0;
% pwpcrit=flipud(real(9.81.*((((1+(alfa.*(-hbase+z)).^n).^(-m))).*((-hbase+z))))); %head profile
% subplot(1,3,1)
% plot(pwpcrit,z,'b'); hold on
% pwpcrit_avg=cumsum(pwpcrit)./cumsum(dz);
% plot(pwpcrit_avg,z,'b--'); hold on

z=linspace(Ho,0,layers)';
dz=ones(layers,1);
pwpcrit_avg=cumsum(U,'reverse')./cumsum(dz,'reverse');

%%Solution Space
% beta=linspace(00,betamax,100)'; %surf slope
%%theta=linspace(-45,89,100); %trial surface angles

beta=beta_slope';
for i=1:1:length(beta)
theta(i,:)=linspace(-beta(i,1)+1,89,1000);
end



%Geometry
W1=(Ho*sind(90-theta)./sind(beta+theta));
H1=(Ho*sind(90-beta)./sind(beta+theta)).*sind(theta);
L1=(Ho*sind(90-beta)./sind(beta+theta)).*cosd(theta);
A1=0.5.*H1.*L1;
W2=(Ho*sind(90-beta)./sind(beta+theta));
H2=(Ho*sind(90-theta)./sind(beta+theta)).*sind(beta);
L2=(Ho*sind(90-theta)./sind(beta+theta)).*cosd(beta);
A2=0.5.*H2.*L2;
Wtotal=W1+W2;

H2(H2>Ho)=Ho;
u=L2.*interp1(z,pwpcrit_avg,H2);

%Forces
%u=0;%linspace(-20,-10,100)'; %pwp
W=(A1+A2).*gamma; %weight
Pp=(W.*sind(theta) + coh.*W2 + (W.*cosd(theta)+kh.*W.*sind(theta)-u).*tand(phi)-kh.*W.*cosd(theta))./(cosd(theta+beta)-sind(theta+beta).*tand(phi));
Pp(Pp<0)=NaN;

%Solve
[Pp_crit,Pp_critloc]=min(Pp,[],2);
% subplot(1,3,2)
% plot(beta,Pp_crit,'r'); hold on
% for i=1:1:length(beta)
% theta_crit(i)=theta(i,Pp_critloc(i));
% end
% subplot(1,3,3)
% plot(beta,theta_crit,'r'); hold on

Kp=Pp/(0.5*Ho*Ho*gamma);

Qyield=Pp_crit';
