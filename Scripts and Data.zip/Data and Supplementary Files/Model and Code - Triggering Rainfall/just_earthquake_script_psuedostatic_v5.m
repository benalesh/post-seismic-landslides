function[yield_flag]=just_earthquake_script_v3_psuedostatic(kh,NR,filename,phi_peak0,phi_res0,theta_avg,blocks,betamax,Ltotal,Ho,res_strain,E)

close all
%clear all
%clc

%tic

%Unsaturated Soils
%-infiltration

%% TOGGLES
maxkploton=0;
ploton=0;
timeseriesplot=0;
profileploton=0;
rootson=1;
excesspwp=0;
%filename='b30_earthquake_NR000.mat';

%% BLOCK GEOMETRY AND DISCRETIZATION PARAMETERS

%%%%%%%%%%%Geometry
%blocks=500; %number of blocks
layers=blocks;% number of layers
%betamax=30; %slope of shear surface
%Ho=1; %depth of soil mantle
Hw=0.0; %height of groundwater table
%Ltotal=20; %total lateral length of landslide
dx=Ltotal/blocks; %lateral width of soil block
dz=Ho/blocks; %shear band thickness
beta=betamax*(0.5+0.5*sawtooth(2*pi*linspace(0,1,blocks),0.25));

beta_surf=beta; %surface slope
beta_slip=beta; %subsurface slope
theta=beta; %interslice angle


%% SOIL PARAMETERS
phi_peak=phi_peak0*ones(1,blocks); %peak friction angle, �
phi_res=phi_res0*ones(1,blocks); %residual friction angle, �
coh=0; %cohesion, kPa
eta=0e1; %dynamic viscosity, kPas/m
gamma_d=15; %unit weight of soil
gamma_w=9.81; %unit weight of water
poisson=0.3; %poisson's ratio
Askempton=0.5;

%Root Parameters
Er=0.000001e1; %young's modulus of roots, kPa
Pdisc=1000;



%% SEISMIC PARAMETERS

kv=0.0;
max_pts=10;

tinc=10; %number of time increments
dt=0.05; %timestep length

tinc=100;
motion_processed(2,:)=horzcat(linspace(0,kh,tinc-1),0);
motion_processed(1,:)=linspace(0,dt*tinc,tinc);
acceleration=motion_processed(2,:);

[kmax,kidx] = maxk(acceleration,max_pts);
kidx=sort(kidx);


%% Rainfall/Groundwater Function

%Hydrologic Parameters
q=0; %infiltration of rainfall
inz=0;
n=1.5;
alfa=3.6; %1/m
sat=0.4;
res=0.05;
gamma_w=9.81; %kN/m
ksat=0.25/24; %m/hour
%theta_avg=0.13; %initial average water content
limit_inf=0; %limit infiltration 
cv=ksat.*10;


[u,dtgw,t,tincGw,infil_actual,cum_infil,Gw,VWC] = hydrostatic_GW_revised(1,Ho,layers,inz,ksat,n,alfa,sat,res,theta_avg,limit_inf);

%% Preprocessing
%Initialize System
test=zeros(layers,blocks);
accel=zeros(layers,blocks);
vel=zeros(layers,blocks);
comp=zeros(layers,blocks);
tens=zeros(layers,blocks);
lat_comp=zeros(layers,blocks);
d_disp=zeros(layers,blocks);
disp_net=zeros(layers,blocks);
disp_profile=zeros(layers,blocks);
disp_step=zeros(layers,blocks);
disp_total=zeros(layers,blocks);
dQ=zeros(layers,blocks);
dQel=zeros(layers,blocks);
dQvisc=zeros(layers,blocks);
dQroots=zeros(layers,blocks);
dQres=zeros(layers,blocks);
dQres_hold=zeros(layers,blocks);
el7=zeros(layers,blocks);
Q=zeros(layers,blocks);
Qres=zeros(layers,blocks);
Uexcess=zeros(layers,blocks);
shear_strain=zeros(layers,blocks);
press_un=zeros(layers,blocks);
press_tri=zeros(layers,blocks);
disp_el=zeros(layers,blocks);
disp_visc=zeros(layers,blocks);
residual=zeros(layers,blocks);
residualpos=zeros(layers,blocks);
residualneg=zeros(layers,blocks);
Qel=zeros(layers,blocks);
Qroots=zeros(layers,blocks);
Qvisc=zeros(layers,blocks);
root_yield=ones(layers,blocks);
maxQel=zeros(layers,blocks);
maxdQres=zeros(layers,blocks);
maxdQhydro=zeros(layers,blocks);
maxQ=zeros(layers,blocks);
maxelcomp=zeros(layers,blocks);
posQel=zeros(layers,blocks);
negQel=zeros(layers,blocks);
phi_step=zeros(layers,blocks);
el_strain=zeros(layers,blocks);
heave=zeros(layers,blocks);
dispt=zeros(tinc,blocks);
velt=zeros(tinc,blocks);
accelt=zeros(tinc,blocks);
compt=zeros(tinc,blocks);
el_compt=zeros(tinc,blocks);
sbt_lengtht=zeros(tinc,1);
maxdispt=zeros(tinc,1);
maxvelt=zeros(tinc,1);
maxaccelt=zeros(tinc,1);
maxcompt=zeros(tinc,1);
maxelcompt=zeros(tinc,1);



fig_count=1;
k_count=1;

yield_flag=0;


%% Function
for t=1:1:tinc


%Hw=Gw(t);

    % Initialize Geometry
%depth=Ho*linspace(Ho/layers,Ho,layers)';
depth=linspace(Ho/layers,Ho,layers)'.*linspace(Ho,1*Ho,blocks+1);
Hwo=depth+(Hw-Ho);
Hwo(Hwo<0)=0;
%Hwo=max([depth+(Hw-Ho),0]);

%Surface and Subsurface Geometry
Linc=repmat(linspace(0,Ltotal,blocks+1),layers,1);
xsurf=Linc;
ysurf=repmat(horzcat(0,cumsum(dx*ones(size(blocks,1))*-tand(beta_surf))),layers,1);
xw=Linc;
yw=repmat(horzcat(0,cumsum(dx*ones(size(blocks,1))*-tand(beta_slip))),layers,1)-depth+Hwo;
xslip=Linc;
yslip=repmat(horzcat(0,cumsum(dx*ones(size(blocks,1))*-tand(beta_slip))),layers,1)-depth;
H=(ysurf(:,2:end) - yslip(:,2:end));
dl=dx./cosd(beta_slip);
A=dx.*0.5.*(ysurf(:,1:end-1)-yslip(:,1:end-1)+ysurf(:,2:end)-yslip(:,2:end)); %Area of Slice
Aw=dx.*0.5.*(yw(:,1:end-1)-yslip(:,1:end-1)+yw(:,2:end)-yslip(:,2:end)); %Area of Water

gamma=gamma_d+gamma_w*VWC;    
%Calculate forces for force equilibrium
W=(A.*gamma); %Weight of Slice
%Resultant of PWP in Slice
U=u.*dx./cosd(beta_slip(:,1:end));

%Preallocation of time-dependent data    
disp_diff=zeros(layers,blocks);

%Softening Function
softening=abs(shear_strain)./res_strain;
softening(softening>1)=1;
phi_step=phi_peak-(phi_peak-phi_res).*(softening);
phi=phi_step;

%Seismic time history
kh=1*acceleration(t);

%Interslice Force
if t==1
   dQ_init=(( W.*(1-kv).*sind(beta_slip) + (W.*kh ).*cosd(beta_slip) - coh.*dl + (-W.*(1-kv).*cosd(beta_slip) + (W.*kh ).*sind(beta_slip) + U).*tand(phi) )...
            ./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) )); 
end
if excesspwp==1
    
Tv=cv.*dt./((Aw./(dx.*2)).^2);
Diss= 1 - (16/(pi^3)).*( (pi-2).*exp((-pi.^2./4).*Tv) + (1/27).*(3.*pi-2).*exp((-9.*pi.^2./4).*Tv) + (1/125).*(5.*pi-2).*exp((-25.*pi.^2./4).*Tv) );
Uexcess=Uexcess-Diss.*Uexcess;
dQ=(( W.*(1-kv).*sind(beta_slip) + (W.*kh ).*cosd(beta_slip) - coh.*dl + (-W.*(1-kv).*cosd(beta_slip) + (W.*kh ).*sind(beta_slip) + U + Uexcess).*tand(phi) )...
            ./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) ));

else
dQ=(( W.*(1-kv).*sind(beta_slip) + (W.*kh ).*cosd(beta_slip) - coh.*dl + (-W.*(1-kv).*cosd(beta_slip) + (W.*kh ).*sind(beta_slip) + U).*tand(phi) )...
            ./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) ));
dQhydro=0*((( W.*sind(beta_slip) - coh.*dl + (-W.*cosd(beta_slip) + U).*tand(phi) )./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) ))-dQ_init);          

dQres(:,2:end)=el7(:,2:end).*(diff(maxQel,1,2).*el7(:,2:end));
dQres(:,2:end)=dQres(:,2:end)-min(dQres(:,2:end).*el7(:,2:end),[],2).*el7(:,2:end);

maxdQres=max(cat(3,maxdQres,(dQres).*el7),[],3);
maxdQhydro=max(cat(3,maxdQhydro,(dQhydro).*el7),[],3);

dQ=dQ+maxdQhydro;


end
        
%find limit of zone 1, dictated by roots, downdrag  
el1=sign(dQ);
el1(el1<0)=0;
el1=-cumsum(el1,2);
el1(el1(:,end)==0,:)=-1;
el1(el1==0)=1;
el1(el1<0)=0;

%find zone 2, dictated by soil+roots, soil shear
el2=sign(dQ);
el2(el2<0)=0;

%find zone 3, dictated by soil ploughing
el3=sign(dQ);
el3(el3<0)=0;
el3=cumsum(el3,2);
el3(el3>0)=1;

%find zone 4, root mobilization
compr=(Er/(E+Er)).*el2.*cumsum(el2.*dQ,2,'reverse'); %mobilization of root tension in unstable zone
tensr=el1.*cumsum(el1.*dQ,2,'reverse'); %mobilization of root tension (downdrag) in headscarp
maxcompr=max(compr,[],2); 
el4=el1.*(tensr+maxcompr); %difference of max value to find upslope cutoff of root tension
el4(el4<0)=0;
el4(el4>0)=1;
el5=el4+el3;

%find compression profile
dcomp1=(el3-el2).*dQ; %ploughing zone
dcomp2=el2.*dQ; %unstable zone
dcomp3=el4.*dQ; %root tension zone
dcomp4=0;%dQroots;  %root resistance in unstable zone
dcomp5=0*dQhydro.*el3;


dcomp=dcomp1+dcomp2-dcomp4+dcomp5; %differential compression profile

comp=cumsum(dcomp,2)-dQroots; %full compression profile
%comp=cumsum(dcomp,2); %full compression profile
comp(comp<0)=0; %no soil tension considered

if t==1
    comp_init=comp;
end


residual=maxQel-comp; %residual compression
residual(residual<0)=0;
add_hydro=sign(residual);
test2=0*add_hydro.*(cumsum(add_hydro.*dQhydro,2,'reverse'));
comp=comp+residual; %add residual compression


%assess root failure
Qroots=el2.*cumsum(dcomp4,2,'reverse');

%find zone 4, where total compression is positive
el6=abs(sign(comp));

%find effective stiffness throughout mantle
Edist=E+Er; %effective stiffness

%Strain Energy and Displacement Profile
lat_comp=el6.*dx.*cumsum(comp.*cosd(theta) - el_strain.*Edist.*H ,2,'reverse','omitnan')+0*add_hydro.*(cumsum(add_hydro.*dQhydro,2,'reverse'));
el_comp=lat_comp./(1+ el6.*dx.*cumsum((el6.*eta.*dl)./(Edist.*H.*dt.*dz),2,'reverse'));

%Calculate Elastic and Viscous Compressive Force Components
Qel(:,1:end-1)=-(1/dx).*diff(el_comp + el6.*dx.*cumsum(el_strain.*Edist.*H,2,'reverse','omitnan'),1,2)./cosd(theta(:,1:end-1));
Qel=Qel.*el6; %effective compression realized
Qvisc=comp-Qel; %force from viscous resistanc

%Displacement components from compression and viscosity
disp_net=el_comp./(Edist.*H); %net compressive displacement profile during timestep
disp_el=lat_comp./(Edist.*H); %max elastic compressive displacement along soil mantle
disp_visc=disp_el-disp_net; %compressive displacement resisted from viscosity along soil mantle

%Displacement and Strains
disp_diff(:,1:end-1)=-diff(disp_net,1,2); %calculate differential displacement 
disp_diff=disp_diff.*el6; %differential displacement realized
disp_step=disp_step+disp_diff; %total differential displacement at end of step
disp_total=disp_total+disp_net; %total compressive displacement profile during timestep
el_strain=disp_step./dx; %compressive strain within layer
heave=el_strain.*poisson.*Ho; %vertical heave (m) throughout profile

dQel(:,1:end-1)=diff(el_strain.*Edist.*H,1,2)./cosd(theta(:,1:end-1));
dQel(:,2:end)=dQel(:,1:end-1).*el6(:,1:end-1);

el7=sign(el_strain);
el7(el7<0)=0;

dQvisc(:,1:end-1)=diff(Qvisc,1,2);
dQvisc(:,2:end)=dQvisc(:,1:end-1).*el7(:,1:end-1);
dQvisc(dQvisc<0)=0;

%Store Previous Data for Change Assessment
disp_profile_previous=disp_profile;
vel_profile_previous=vel;

%maximum elastic compression throughout analysis
maxQel=max(cat(3,maxQel,Qel),[],3);
maxQel=maxQel.*el6;

maxQ=(Qvisc-maxQel).*el7;

%Find incremental residual compression 
dQres_hold(:,2:end)=diff(maxQel,1,2).*el7(:,2:end)-dQ_init(:,2:end).*el7(:,2:end);
dQres_hold(:,2:end)=diff(residual,1,2);

%Calculate Cumulative Displacement Profile
d_disp(2:end,:)=diff(disp_total,1); %find incremental displacement stemming from each layer with depth
disp_profile=cumsum(d_disp,1,'reverse'); %displacement profile
shear_strain=d_disp;

%RFBM Mobilization
root_disp=max(disp_profile,[],1);
[Troot]= rfbm_weibull_multi(Pdisc,NR,root_disp);

[max_root_t,max_root_t_loc]=max(max(disp_profile));
Troot(Troot>(Troot(max_root_t_loc)))=Troot(max_root_t_loc);

dQroots=(linspace(1,1,layers)').*(Troot);


%Calculate Shear Band Width and Length along Slope Length
sbt_width=dz.*sum(sign(disp_total),1);
sbt_lengtht(t,1)=dx*sum(sign(sum(sign(disp_total),1)));

%Calculate Velocity and Acceleration Profile Time Series
vel=(disp_profile-disp_profile_previous)/dt;
accel=(vel-vel_profile_previous)/dt;   

%yield
kp=real((cosd(phi).^2)./((1-sqrt( (sind(phi).*(sind(phi_peak-beta)))./(cosd(-beta)))).^2));
Qyield=gamma.*depth(:,1:end-1).*depth(:,1:end-1).*kp;
ko=1-sind(phi);
%yield function
[Qyield]=yield_function_script_rainfall_v2(Ho,layers,gamma,gamma_w,phi_peak0,coh,beta_slip,kh,u);

%volume change
dV=el_strain.*poisson;
Uexcess=Uexcess+Askempton.*el_comp./H;

%Store Time Series of Landslide Behavior
dispt(t,:)=disp_profile(1,:);
velt(t,:)=vel(1,:);
accelt(t,:)=accel(1,:);
compt(t,:)=comp(end,:);
el_compt(t,:)=Qel(end,:);
maxdispt(t,1)=max(dispt(t,:));
maxvelt(t,1)=max(velt(t,:));
maxaccelt(t,1)=max(accelt(t,:));
maxcompt(t,1)=max(compt(t,:));
maxelcompt(t,1)=max(el_compt(t,:));
Qyieldt(t,:)=Qyield(end,:);
Qrootst(t,:)=Qroots(end,:);
dQrest(t,:)=dQres(end,:);
yield(t,:)=Qyieldt(t,:)-compt(t,:)+Troot;

if min(yield(t,:))<0 && yield_flag==0
    
    [yield_rem,yield_idx]=min(yield(t,:));
    
    if t>1         
    [tyield,yieldval]=polyxpoly([t*dt, (t-1)*dt],[yield(t,yield_idx),yield(t-1,yield_idx)],[t*dt, (t-1)*dt],[0, 0]);
    tyield;

    else
    tyield=0; %yield time
    tyield;

    end

    yield_loc=(Linc(1,yield_idx)); %yield location of toe
    [aa,bb]=min(sign(-dispt(t,:))); %yield location of head
    yield_length=(Linc(1,yield_idx))-(Linc(1,bb));
    yield_flag=1;
    %break
elseif yield_flag==0 && Hw==Ho
    
            tyield=NaN;
    yield_length=NaN;
    %break
    
    
    
    
end


%% PLOTTING


if sum(t==kidx)==1
    
if maxkploton==1
    

%% SEISMIC PLOTTING
figure(fig_count);
subplot(4,1,1)
plot(Linc(1,1:end-1),disp_profile(1,:),'Color',[(k_count/(max_pts+1)) 0 1-(k_count/(max_pts+1))])
hold on; 
grid on
xlabel('X [m]')
ylabel('Surface Displacement [m]');

subplot(4,1,2)
plot(Linc(1,1:end-1),sbt_width/Ho,'Color',[(k_count/(max_pts+1)) 0 1-(k_count/(max_pts+1))])
hold on; 
grid on
xlabel('X [m]')
ylabel('Shear Band Thickness [z_{SB}/H]');
ylim([0 1])


subplot(4,1,3)
%plot(Linc(1,1:end-1),comp(end,:),'k');
hold on; 
plot(Linc(1,1:end-1),Qel(end,:),'-','Color',[(k_count/(max_pts+1)) 0 1-(k_count/(max_pts+1))]) 
%plot(Linc(1,1:end-1),-Qvisc(end,:),':','Color',[(t/tinc) 0 1-(t/tinc)])
plot(Linc(1,1:end-1),Qyield(end,:),'Color','k');


grid on
xlabel('X [m]')
ylabel('Force [kN]');
% legend('Available Compressive Load','Elastic Compression','Mobilized Viscous Resistance');
legend('Compression');

subplot(4,1,4)
%plot(Linc(1,1:end-1),comp(end,:),'k');
hold on; 
plot(Linc(1,1:end-1),Qroots(end,:),'-','Color',[(k_count/(max_pts+1)) 0 1-(k_count/(max_pts+1))]) 
%plot(Linc(1,1:end-1),root_tens.*ones(1,blocks),'Color','k');

grid on
xlabel('X [m]')
ylabel('Force [kN]');
% legend('Available Compressive Load','Elastic Compression','Mobilized Viscous Resistance');
legend('Mobilized Root Tension');



k_count=k_count+1;

end
    
    
    
end


%toc
%end of time solver
end

dQres_init=dQres;(dQ-dQ_init);    %dQres_init+(dQ-dQ_init).*el7;
%dQres_init(dQres_init<0)=0;
el_res=sign(dQres_init);
el_res(el_res<0)=0;


if ploton==1
    

%% FINAL PLOTTING
figure(fig_count);
subplot(4,1,1)
plot(Linc(1,1:end-1),disp_profile(1,:),'Color',[(t/tinc) 0 1-(t/tinc)])
hold on; 
grid on
xlabel('X [m]')
ylabel('Surface Displacement [m]');

subplot(4,1,2)
plot(Linc(1,1:end-1),sbt_width/Ho,'Color',[(t/tinc) 0 1-(t/tinc)])
hold on; 
grid on
xlabel('X [m]')
ylabel('Shear Band Thickness [z_{SB}/H]');
ylim([0 1])

subplot(4,1,3)
%plot(Linc(1,1:end-1),comp(end,:),'k');
hold on; 
plot(Linc(1,1:end-1),Qel(end,:),'-','Color',[(k_count/(max_pts+1)) 0 1-(k_count/(max_pts+1))]) 
%plot(Linc(1,1:end-1),-Qvisc(end,:),':','Color',[(t/tinc) 0 1-(t/tinc)])
plot(Linc(1,1:end-1),Qyield(end,:),'Color','k');
legend('Compression','Compressive Yield');

grid on
xlabel('X [m]')
ylabel('Force [kN]');
% legend('Available Compressive Load','Elastic Compression','Mobilized Viscous Resistance');
legend('Compression');

subplot(4,1,4)
%plot(Linc(1,1:end-1),comp(end,:),'k');
hold on; 
plot(Linc(1,1:end-1),Qroots(end,:),'-','Color',[(k_count/(max_pts+1)) 0 1-(k_count/(max_pts+1))]) 
%plot(Linc(1,1:end-1),root_tens.*ones(1,blocks),'Color','k');

grid on
xlabel('X [m]')
ylabel('Force [kN]');
% legend('Available Compressive Load','Elastic Compression','Mobilized Viscous Resistance');
legend('Mobilized Root Tension');


fig_count=fig_count+1;

end

%% TIME SERIES PLOTTING

if timeseriesplot==1
figure(fig_count);

subplot(5,1,1)
plot(motion_processed(1,:),acceleration,'k');
grid on
xlabel('Time [s]')
ylabel('Seismic Acceleration [g]')

subplot(5,1,2)
plot(motion_processed(1,:),maxdispt,'k');
grid on
xlabel('Time [s]')
ylabel('Displacement [m]')

subplot(5,1,3)
plot(motion_processed(1,:),Troot_t,'k');
grid on
xlabel('Time [s]')
ylabel('Root Mobilization [kN]')

subplot(5,1,4)
plot(motion_processed(1,:),maxelcompt,'k');
grid on
xlabel('Time [s]')
ylabel('Max. Landslide Compression [kN]')

subplot(5,1,5)
plot(motion_processed(1,:),sbt_lengtht,'k');
grid on
xlabel('Time [s]')
ylabel('Shear Band Length [m]')
  
fig_count=fig_count+1;
    
end

save(filename);

%% PROFILE PLOT



if profileploton==1
%Displacement Contours
figure
for layer=1:1:layers
    disp_profile(disp_profile<0)=0;
depth=Ho*(layer)/layers;
Hwo=max([depth+(Hw-Ho),0]); 


%Initialize Geometry
Linc=linspace(0,Ltotal,blocks+1)';
xsurf=Linc;
ysurf=horzcat(0,cumsum(dx*ones(size(blocks-1,1))*-tand(beta_surf)))';
xw=Linc;
yw=horzcat(0,cumsum(dx*ones(size(blocks-1,1))*-tand(beta_slip))-depth+Hwo)';
xslip=Linc;
yslip=horzcat(0,cumsum(dx*ones(size(blocks-1,1))*-tand(beta_slip))-depth)';
H(layer,:)=(ysurf(2:end) - yslip(2:end))';

M=vertcat(disp_profile(layer,1)',disp_profile(layer,:)');
N = length(xsurf);
verts = [xsurf(:), yslip(:)+dz; xslip(:), yslip(:)];

q = (1:N-1)';
faces = [q, q+1, q+N+1, q+N];
p = patch('Faces', faces, 'Vertices', verts, 'FaceVertexCData', [M(:); M(:)], 'FaceColor', 'interp', 'EdgeColor', 'none');
xlabel('X [m]')
ylabel('Y [m]')
colormap jet
grid on
hold on

%toc
end

axis equal
c = colorbar;
c.Label.String = 'Displacement [m]';
c.Location='east';
end
