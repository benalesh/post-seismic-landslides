function [p_u,p_w,p_l,d_u_inc,d_w_inc,d_l_inc] = rootd_pdf(Pdisc)


%% Root Probability Functions

d1=0.01; %min root diameter (mm)
d2=5; %max root diameter (mm)

%Uniform
da=0.997; %(mm)
db=2.84;  %(mm)
d_u=linspace(da,db,Pdisc);
d_u_inc=(db-da)/Pdisc;
%p_u=(d./d)*1/(db-da); %probability
p_u=(d_u./d_u)*1/(db-da); %probability
% p_u(p_u<da)=0;
% p_u(p_u>db)=0;

%Weibull
d_w=linspace(d1,d2,Pdisc);
d_w_inc=(d2-d1)/Pdisc;
md=3.38; %unitless
kd=2.15; %(mm)
p_w=(md/kd)*((d_w/kd).^(md-1)).*exp(-(d_w/kd).^md);

%Lognormal
d_l=linspace(d1,d2,Pdisc);
d_l_inc=(d2-d1)/Pdisc;
mud=-6.28; %mean of ln(diameter)
sigd=0.349; %std dev of ln(diameter)
p_l=(1./(sqrt(2*pi)*sigd.*d_l)).*exp(-(((log(d_l*1e-3)-mud).^2)./(2*(sigd^2))));

%Plot Diameter Distributions
figure('Name','Diameter Distribution');

subplot(1,2,1) %Plot PDFs of Root Diameter
hold on
plot(d_u,p_u,'r')
plot(d_w,p_w,'b')
plot(d_l,p_l,'g')
grid on
xlabel('\phi [mm]')
ylabel('P(\phi) [ ]')
xlim([0 5])
ylim([0 1])

subplot(1,2,2) %Plot CDFs of Root Diameter
hold on
plot(d_u,cumsum(p_u*d_u_inc),'r')
plot(d_w,cumsum(p_w*d_w_inc),'b')
plot(d_l,cumsum(p_l*d_l_inc),'g')
grid on
xlabel('\phi [mm]')
ylabel('P(\phi) [ ]')
xlim([0 5])
ylim([0 1])