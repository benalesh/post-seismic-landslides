function [Troot]= rfbm_weibull_multi(Pdisc,NR,disp)

%Weibull Distribution

%Diameter
mphi=2.56;2.56;3.38; %dimensionless
kphi=12.15;2.15; %mm
lambda=1.28;1.28;1.28;

Fo=22.1; %N/mm
Do=1; %mm

%Force
% mf=2.56;2.64; %dimensionless
% kf=58.7; %Newtons

mf=mphi/lambda; %dimensionless
kf=Fo*((kphi/Do)^lambda); %dimensionless

%stiffness
kappa=0.29;0.29;0.23;0.23;0.21;0.31;0.31;0.29;0.29; %0.21 for best fit wth cohesiion 1/31
Wo=(36.2/(1-kappa))*(1e1);%.^(1-kappa); %MN/mm


Troot=real(NR*Wo.*(kf.^kappa).*disp.*igamma( (kappa/mf)+1 , ((Wo.*disp).^(mf/(1-kappa)))./(kf.^mf) ))./1000; %/1000 to correct for kN


