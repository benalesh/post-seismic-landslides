function [meanF_u,meanF_w,meanF_l,PR_u,PR_w,PR_l,Fa,Fb,mF,kF,muF,sigF] = root_pdf(Pdisc,kappa,Wo,lambda,Fo,NR)


%% Root Diameter Probability Functions

d1=0.01; %min root diameter (mm)
d2=5; %max root diameter (mm)

%Uniform
da=0.997; %(mm)
db=2.84;  %(mm)
d_u=linspace(da,db,Pdisc);
d_u_inc=(db-da)/Pdisc;
p_u=(d_u./d_u)*1/(db-da); %probability

%Weibull
d_w=linspace(d1,d2,Pdisc);
d_w_inc=(d2-d1)/Pdisc;
md=3.38; %unitless
kd=2.15; %(mm)
p_w=(md/kd)*((d_w/kd).^(md-1)).*exp(-(d_w/kd).^md);

%Lognormal
d_l=linspace(d1,d2,Pdisc);
d_l_inc=(d2-d1)/Pdisc;
mud=-6.28; %mean of ln(diameter)
sigd=0.349; %std dev of ln(diameter)
p_l=(1./(sqrt(2*pi)*sigd.*d_l)).*exp(-(((log(d_l*1e-3)-mud).^2)./(2*(sigd^2))));


% figure(1);
% %Plot Diameter Distributions
% subplot(2,2,1) %Plot PDFs of Root Diameter
% hold on
% plot(d_u,p_u,'r')
% plot(d_w,p_w,'b')
% plot(d_l,p_l,'g')
% grid on
% xlabel('\phi [mm]')
% ylabel('P(\phi) [ ]')
% xlim([0 5])
% ylim([0 1])
% 
% subplot(2,2,2) %Plot CDFs of Root Diameter
% hold on
% plot(d_u,cumsum(p_u*d_u_inc),'r')
% plot(d_w,cumsum(p_w*d_w_inc),'b')
% plot(d_l,cumsum(p_l*d_l_inc),'g')
% grid on
% xlabel('\phi [mm]')
% ylabel('P(\phi) [ ]')
% xlim([0 5])
% ylim([0 1])



%% Root Force Probability Functions

F1=0.01; %min root force
F2=200; %max root diameter (mm)

%Uniform
Fa=22; %(N)
Fb=83; %(N)
F_u=linspace(Fa,Fb,Pdisc); %create array of possible forces for probability assessment
F_u_inc=(Fb-Fa)/Pdisc; %find uniform force increment discretization
pF_u=(F_u.^((1-lambda)/lambda))./(lambda*((Fb^(1/lambda))-(Fa^(1/lambda)))); %force probability
meanF_u=(1/(1+lambda))*((Fb^((1+lambda)/lambda))-(Fa^((1+lambda)/lambda)))/((Fb^(1/lambda))-(Fa^(1/lambda)));

%Weibull
F_w=linspace(F1,F2,Pdisc);
F_w_inc=(F2-F1)/Pdisc;
mF=2.64; %unitless
kF=58.7; %(N)
pF_w=(mF/kF)*((F_w/kF).^(mF-1)).*exp(-(F_w/kF).^mF);
meanF_w=kF*(gammainc(0.5,(1/mF)+1,'upper'));


%Lognormal
F_l=linspace(F1,F2,Pdisc);
F_l_inc=(F2-F1)/Pdisc;
muF=3.90; %mean of ln(Newtons)
sigF=0.447; %std dev of ln(Force, Newtons)
pF_l=(1./(sqrt(2*pi)*sigF.*F_l)).*exp(-(((log(F_l)-muF).^2)./(2*(sigF^2))));
meanF_l=exp(((sigF^2)/2)+muF);


% %Plot Force Distributions
% subplot(2,2,3) %Plot PDFs of Root Diameter
% hold on
% plot(F_u,pF_u,'r')
% plot(F_w,pF_w,'b')
% plot(F_l,pF_l,'g')
% grid on
% xlabel('F [N]')
% ylabel('P(F) [ ]')
% xlim([0 200])
% ylim([0 0.025])
% 
% subplot(2,2,4) %Plot CDFs of Root Diameter
% hold on
% plot(F_u,cumsum(pF_u*F_u_inc),'r')
% plot(F_w,cumsum(pF_w*F_w_inc),'b')
% plot(F_l,cumsum(pF_l*F_l_inc),'g')
% grid on
% xlabel('F [N]')
% ylabel('P(F) [ ]')
% xlim([0 200])
% ylim([0 1])


%% Calculate Breakage Relationship

i=1;
for disp=0.00:0.001:0.25
    
[PR_u,PR_w,PR_l]=rootforce_disp(disp,kappa,lambda,Wo,meanF_u,meanF_w,meanF_l,Fa,Fb,mF,kF,muF,sigF);

Pxu(i,1)=NR*PR_u;
Pxw(i,1)=NR*PR_w;
Pxl(i,1)=NR*PR_l;
dx(i,1)=disp;

i=i+1;
end

% figure(2);
% plot(dx,Pxu,'r');
% hold on
% plot(dx,Pxw,'b');
% plot(dx,Pxl,'g');
% 
% grid on
% xlabel('Displacement [m]')
% ylabel('Force [N]')







