
function [Troot,meanF_u,meanF_w,meanF_l,PR_u,PR_w,PR_l,Fa,Fb,mF,kF,muF,sigF]= rfbm_initialize(Pdisc,NR,disp)

%Root Strength
To=28.1; % (MPa/mm^alpha)Mpa mm
alpha=0.72;

do=0.001; %reference diameter, phi_o

%Root ductility
Eo=696; %(MPa/mm^beta) reference elastic modulus, Eo
beta=1.00;

%Root Length
Lo=335; %reference embedment length, Lo
gamma=0.63;

%Root force
Fo=22.1; %(N/mm^(-lambda))
lambda=1.28;

%Root Displacement Yield Parameters
Wo=36.2*10; %(MN^(1-kappa)/mm) 
kappa=0.289; 


[meanF_u,meanF_w,meanF_l,PR_u,PR_w,PR_l,Fa,Fb,mF,kF,muF,sigF] = root_pdf(Pdisc,kappa,Wo,lambda,Fo,NR);

%Time Series

[PR_u,PR_w,PR_l]=rootforce_disp(disp,kappa,lambda,Wo,meanF_u,meanF_w,meanF_l,Fa,Fb,mF,kF,muF,sigF);
Troot=(PR_l/1000)*NR; %parallel force