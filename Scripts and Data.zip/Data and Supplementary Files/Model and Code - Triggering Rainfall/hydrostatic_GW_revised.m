function[u,dt,t,tinc,infil_actual,cum_infil,Gw,VWC] = hydrostatic_GW_revised(tinc,depth,inc,inz,ksat,n,alfa,sat,res,theta_surf,limit_inf)


%close all
%clear all
%clc

%Geometry Domain
%depth=3;
%inc=50;
dz=depth/inc;

%Time Domain
%tinc=100;
to=0;
tf=200;
dt=(tf-to)/tinc;
t=to:dt:tf;
infil_actual=tinc*dt*inz;
cum_infil=infil_actual;

%Soil Parameters
%n=3.177;
m=1-(1/n);
%alfa=9.81*0.0352; 9.81*(10^-1.453); %1/m %%%%%%%%%%%%%%CHECK UNITS
%sat=0.375;
%res=0.053;
gamma_w=9.81; %kN/m
%ksat=2.808*0.000417; %m/hour

%Antecedent Conditions
h0threshold=0; %head at base of soil column that represents buildup of saturatation 
%theta_avg=0.1865; %theta to solve for. This is initial average water content, or the water content being solve for in each time step.
%theta_surf=0.12;

%Rainfall Parameters
%inz=1e-3; %infiltration, m/day

%Preallocation
h0=logspace(-3,2,inc); %represents the search range for head, each represents a guess that is assessed for closure/convergence
h=h0+linspace(0,depth,inc)'; %discretize head over depth for each guess, this is capillary stress
z=linspace(0,depth,inc)';
hthreshold=linspace(h0threshold,h0threshold+depth,inc)'; %threshold head for column base becoming saturated
h0crit=zeros(tinc,1);
hbase=zeros(tinc,1);
depthsat=linspace(0,20,1000);
depthsat_lin=linspace(0,depth,inc)'-linspace(0,20,1000);
depthsat_lin(depthsat_lin<0)=0;
sat_token=1;


%% INITIAL CONDITIONS

%find surface and basal volumetric water content that implies the onset of basal saturation
Wthreshold=sum(res + (sat-res).*((1+(alfa.*hthreshold).^n).^(-m))).*dz; %W represents the water height
theta_threshold=Wthreshold./depth; %threshold average water content for base to be saturated
theta_surf_threshold=res + (sat-res).*((1+(alfa.*depth).^n).^(-m)); %threshold surface water content for base to be saturated

if theta_surf<theta_surf_threshold %unsaturated initial conditions
    %disp('Base is not saturated.')
    
    %fit to surface moisture, get average water content
    theta0=res + (sat-res).*((1+(alfa.*h).^n).^(-m));
    W=sum(res + (sat-res).*((1+(alfa.*h).^n).^(-m)),1).*dz; %W represents the water height
    error=(theta0(end,:)-theta_surf).^2; %find difference between goal (average) theta and range of possible SWRCC
    [minerr_surf,minerrloc_surf]=min(error);

    %get depth beyond base of column where saturated conditions exist
    h0crit_init=h0(minerrloc_surf);
    
    %finalize initial conditions
    VWC_crit=res + (sat-res).*((1+(alfa.*(h0crit_init+z)).^n).^(-m));
    theta_avg=mean(VWC_crit);
%     subplot(1,2,1)
%     plot(VWC_crit,z,'k','LineWidth',2); hold on
    theta_avg;
    init_groundwater_depth=h0crit_init+depth;
    
elseif theta_surf>theta_surf_threshold %saturated initial conditions
    %disp('Base is saturated.')
    
    %fit to surface moisture, get average water content
    theta=res + (sat-res).*((1+(alfa.*depthsat_lin).^n).^(-m));
    mean_theta=mean(theta,1);
    error=(theta(end,:)-theta_surf).^2; %find difference between goal (average) theta and range of possible SWRCC
    [minerr_surf,minerrloc_surf]=min(error);
    theta_avg=mean(theta(:,minerrloc_surf));

    %get saturated depth
    hgw=depthsat(minerrloc_surf); %groundwater height
    zcap=z-hgw; %height of capillary zone
    zcap(zcap<=0)=0;
    zsat=z-hgw;
    zsat(zsat>=0)=0;

    %finalize initial conditions
%     VWC_crit=res + (sat-res).*((1+(alfa.*(zcap)).^n).^(-m));
%     subplot(1,2,1)
%     plot(VWC_crit,z,'k','LineWidth',2); hold on
    theta_avg; 
    init_groundwater_depth=depth-hgw;
    
end  
    
%% RUNOFF AND PONDING - IGNORE FOR NOW
A1=ksat/2; %infiltration regulated by hydraulic conductivity
dVWC=(sat-res)/100;
VWCspace=linspace(theta_avg,sat,100);
D=((1-m).*ksat/(alfa.*m.*(sat-res))).*(VWCspace.^(0.5-(1./m))).*(((1-VWCspace.^(1/m)).^-m) + ((1-VWCspace.^(1/m)).^m) -2); %VG diffusivity
S=sqrt(2.*(sat-res).*dVWC.*sum(D)); %sorptivity
tc=((S.^2).*(2.*inz - A1))./(4.*inz.*((inz-A1).^2));
tp=(S.^2)./(4*((inz-A1).^2));

%Calculate Actual Infiltration using Philips (1957) Equation 
t_noponding=sign(t-tc);
t_noponding(t_noponding>0)=0;
t_noponding(t_noponding<0)=1;
t_noponding(1)=0;
t_ponding=sign(t-tc);
t_ponding(t_ponding<=0)=0;
t_ponding(t_ponding>0)=1;
inz_actual=t_noponding.*inz+t_ponding.*(0.5*S.*((t-(tc-tp)).^-0.5) + A1);
inz_actual(inz_actual>inz)=inz;

sum(inz_actual).*dt;
  
%% TRANSIENT RESPONSE TO RAINFALL
for k=1:1:tinc
inz_actual(k)=inz;  
    %Calculate change in average water content from rainfall (i.e. bucket analogy)
    dtheta=inz_actual(k).*dt./depth;
    theta_avg=theta_avg+dtheta;
    theta_avg(theta_avg>sat)=sat;
    
    %Solve for appropriate head that satisfies average VWC during timestep 
    W=sum(res + (sat-res).*((1+(alfa.*h).^n).^(-m)),1).*dz; %W represents the water height
    theta=W./depth; %volumetric water content at base
    error=(theta-theta_avg).^2; %find difference between goal (average) theta and range of possible SWRCC
    [minerr,minerrloc]=min(error);
    h0crit(k,1)=h0(minerrloc); %critical h0, i.e. potential head at bottom of soil column

%if exceeds threshold for saturation, calculate standing saturated depth
if theta_avg>=theta_threshold
    
    if sat_token==1 %time when saturation occurs
        tsat=k*dt;
        sat_token=0;
    end
    
    %find VWC profile with saturated portion that yields appropriate average water content
    theta=res + (sat-res).*((1+(alfa.*depthsat_lin).^n).^(-m));
    mean_theta=mean(theta,1);
    error=(mean_theta-theta_avg).^2; %find difference between goal (average) theta and range of possible SWRCC
    [minerr_surf,minerrloc]=min(error);

    %get saturated depth and height of capillary layer
    hgw(k,1)=depthsat(minerrloc); %groundwater height
    zcap=z-hgw(k,1); %height of capillary zone
    zcap(zcap<=0)=0;
    zsat=z-hgw(k,1);
    zsat(zsat>=0)=0;
    hgw(hgw>depth)=depth;
    hbase(k,1)=0;hgw(k,1);
    
    %head, VWC and pwp profile in saturated column
    hcrit(:,k)=zsat+((((1+(alfa.*(-hbase(k,1)+zcap)).^n).^(-m))).*((-hbase(k,1)+zcap))); %head profile
    pwpcrit(:,k)=-gamma_w.*hcrit(:,k);
    VWC_crit=res + (sat-res).*((1+(alfa.*(zcap)).^n).^(-m));
    
    %store relevant data
    t_VWC(:,k)=VWC_crit; %VWC profile time series
    t_theta_avg(k,1)=theta_avg; %average water content time series
    t_basal_pwp(k,1)=pwpcrit(1,k); %basal pwp time series
    t_depth_gw(k,1)=depth-hgw(k,1); %groundwater depth time series
    
    %plot
%     subplot(1,2,1)
%     plot(VWC_crit,z,'r','LineWidth',1); hold on; grid on
%     subplot(1,2,2); hold on
%     plot(pwpcrit(:,k),(z),'b'); hold on; grid on
%     xlabel('Pore Water Pressure [kPa]')
%     ylabel('Soil Height [m]')

    
else
    %get saturated depth beyond base of column and height of capillary layer
    hbase(k,1)=-h0crit(k,1);
    hgw(k,1)=0;
    %hcrit(:,k)=((res + (sat-res).*((1+(alfa.*(-hbase(k,1)+z)).^n).^(-m))).*((-hbase(k,1)+z))./sat); %VWC profile
    hcrit(:,k)=((((1+(alfa.*(-hbase(k,1)+z)).^n).^(-m))).*((-hbase(k,1)+z))); %head profile
    pwpcrit(:,k)=-gamma_w.*hcrit(:,k);
    VWC_crit=res + (sat-res).*((1+(alfa.*(-hbase(k,1)+z)).^n).^(-m));
        
    %store relevant data
    t_VWC(:,k)=VWC_crit; %VWC profile time series
    t_theta_avg(k,1)=theta_avg; %average water content time series
    t_basal_pwp(k,1)=pwpcrit(1,k); %basal pwp time series
    t_depth_gw(k,1)=h0crit(k,1)+depth; %groundwater depth time series
        
    %plot 
%     subplot(1,2,1)
%     plot(VWC_crit,z,'r','LineWidth',1); hold on; grid on
%     subplot(1,2,2); hold on
%     plot(pwpcrit(:,k),(z),'r'); hold on; grid on
%     xlabel('Pore Water Pressure [kPa]')
%     ylabel('Soil Height [m]')
 
end

theta_goal_store(k,1)=theta_avg;

% drawnow
% pause(0.01);
theta_avg;
end

u=flipud(pwpcrit);
VWC=flipud(VWC_crit);
Gw=hgw;

%toc;



