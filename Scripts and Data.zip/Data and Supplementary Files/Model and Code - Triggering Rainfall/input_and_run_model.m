
%close all
clear all
clc

run_seismic=1; %run seismic code
run_precip=1; %run post-seismic rainfall
plot_data=0; %plot data

phi_peak=30; %peak friction angle  [°]
phi_res=30; %residual friction angle [°]

surfVWC=0.17; %surface vol. water content [m3/m3]
blocks=400; %spatial discretization [ ]
betamax=30; %max. slope angle [°]
Ltotal=55; %total length of soil mantle [m]
Ho=1; %soil mantle thickness [m]
res_strain=0.05; %residual shear strain [m/m]

for E=[2e3] %compressive modulus [kPa]
    
    for NR=[25 50 100] %number of roots [ ]

        seismic_output=strcat('refinedveg_seismic_b',num2str(betamax),'_E',num2str(E),'_NR',num2str(NR),'.mat');
        rainfall_output=strcat('refinedveg_rainfall_b',num2str(betamax),'_E',num2str(E),'_NR',num2str(NR),'.mat');
        
%% SEISMIC INITIAL CONDITIONS
if run_seismic==1%run seismic initial conditions  

    
    
    kcount=1;
    
    for betamax=30
        
        for kh=0.0:0.01:0.5 

        filename{kcount}=strcat('Outputs\b',num2str(betamax),'_kh',num2str(kh),'_NR',num2str(NR),'_hydrostatic_',num2str(phi_peak-phi_res),'softening.mat');   
        [yield_flag]=just_earthquake_script_psuedostatic_v5(kh,NR,filename{kcount},phi_peak,phi_res,surfVWC,blocks,betamax,Ltotal,Ho,res_strain,E);
        PGA(kcount,1)=kh;
        coseismic(kcount,1)=yield_flag;
        kcount=kcount+1;
        kh
        end

        
        
    end

save(seismic_output);

end



%% RUN RAINFALL THRESHOLDS

if run_precip==1
    
load(seismic_output)    
ksat=0.25/24; %m/hour
count=1;
infiltration=1e-3;logspace(-4,-1,20);
duration=1./infiltration;
cycles=1;
tic

    for j=1:1:length(filename)

        
        for i=1:1:length(infiltration)
            
            j
            i
            
            inz=infiltration(i); %time-dependent, infiltration flux, L/T
            tf_s=duration(i); %final time, T, hours

        [tyield(i,j),yield_ltoe(i,j),yield_length(i,j)]=cyclic_rainfall_after_earthquake_script_v5(inz, ksat, filename{j},tf_s,cycles);
        precip(i,j)=inz.*tyield(i,j);


        toc
        end


    end
save(rainfall_output);
end

    end
    
    
end
plot(PGA,precip,'b');
hold on
yyaxis right
plot(PGA, yield_length,'r')

if plot_data==1

load(rainfall_output) 
subplot(1,2,1)
loglog(infiltration,tyield(:,1),'LineWidth',2,'Color','k'); hold on
for i=1:1:13    
loglog(infiltration,tyield(:,i),'LineWidth',2,'Color',[(i)/13 0 1-((i)/13)]); hold on

end

grid on
xlabel('Rainfall Intensity [m/hour]')
ylabel('Rainfall Duration to Failure [hours]')

legend('No Earthquake','PGA=0.05g','PGA=0.10g','PGA=0.15g','PGA=0.20g')

subplot(1,2,2)

plot(tyield(1,1:13)./tyield(1,1),'LineWidth',2,'Color','r'); hold on



end

