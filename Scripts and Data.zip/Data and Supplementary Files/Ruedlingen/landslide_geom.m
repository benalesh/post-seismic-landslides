clearvars -except rawsurfdata_geom rawslipdata_geom

import_data=0;

if import_data==1

rawsurfdata_geom=xlsread('ruedlingen_data.xlsx',2,'A2:B23');
rawslipdata_geom=xlsread('ruedlingen_data.xlsx',2,'C2:D32');





end

%Discretization
blocks=100;
layers=100;

%Raw Data
xmax=56.5;
slices=100;
x=linspace(0,xmax,blocks+1);
xsurf0=rawsurfdata_geom(:,1);
ysurf0=rawsurfdata_geom(:,2);
xslip0=rawslipdata_geom(:,1);
yslip0=rawslipdata_geom(:,2);

%Interpolate Geometric Data
xsurf=x;
ysurf=interp1(xsurf0,ysurf0,x);
xslip=x;
yslip=interp1(xslip0,yslip0,x);
beta_surf=-atand(diff(ysurf)./diff(xsurf));
beta_slip=-atand(diff(yslip)./diff(xslip));

%Depth of Soil Mantle
dx=xmax/blocks;
Ho=ysurf-yslip;
depth=(linspace(0.01,1,layers)').*Ho;
dl=dx./cosd(beta_slip);
A=dx.*0.5.*(ysurf(:,1:end-1)-yslip(:,1:end-1)+ysurf(:,2:end)-yslip(:,2:end)); %Area of Slice

%Calculate forces for force equilibrium
W=(A*gamma); %Weight of Slice
U=u.*dx./cosd(beta(:,1:end)); %Resultant of PWP in Slice

%% Preprocessing
%Initialize System
test=zeros(layers,blocks);
accel=zeros(layers,blocks);
vel=zeros(layers,blocks);
comp=zeros(layers,blocks);
tens=zeros(layers,blocks);
lat_comp=zeros(layers,blocks);
d_disp=zeros(layers,blocks);
disp_net=zeros(layers,blocks);
disp_profile=zeros(layers,blocks);
disp_step=zeros(layers,blocks);
disp_total=zeros(layers,blocks);
dQ=zeros(layers,blocks);
dQel=zeros(layers,blocks);
dQvisc=zeros(layers,blocks);
dQroots=zeros(layers,blocks);
dQres=zeros(layers,blocks);
dQres_hold=zeros(layers,blocks);
el7=zeros(layers,blocks);
Q=zeros(layers,blocks);
Qres=zeros(layers,blocks);
Uexcess=zeros(layers,blocks);
shear_strain=zeros(layers,blocks);
press_un=zeros(layers,blocks);
press_tri=zeros(layers,blocks);
disp_el=zeros(layers,blocks);
disp_visc=zeros(layers,blocks);
residual=zeros(layers,blocks);
residualpos=zeros(layers,blocks);
residualneg=zeros(layers,blocks);
Qel=zeros(layers,blocks);
Qroots=zeros(layers,blocks);
Qvisc=zeros(layers,blocks);
root_yield=ones(layers,blocks);
maxQel=zeros(layers,blocks);
maxdQres=zeros(layers,blocks);
maxdQhydro=zeros(layers,blocks);
maxQ=zeros(layers,blocks);
maxelcomp=zeros(layers,blocks);
posQel=zeros(layers,blocks);
negQel=zeros(layers,blocks);
phi_step=zeros(layers,blocks);
el_strain=zeros(layers,blocks);
heave=zeros(layers,blocks);
dispt=zeros(tinc,blocks);
velt=zeros(tinc,blocks);
accelt=zeros(tinc,blocks);
compt=zeros(tinc,blocks);
el_compt=zeros(tinc,blocks);
sbt_lengtht=zeros(tinc,1);
maxdispt=zeros(tinc,1);
maxvelt=zeros(tinc,1);
maxaccelt=zeros(tinc,1);
maxcompt=zeros(tinc,1);
maxelcompt=zeros(tinc,1);

for t=1:1:tinc

%Preallocation of time-dependent data    
disp_diff=zeros(layers,blocks);

%Softening Function
softening=abs(shear_strain)./res_strain;
softening(softening>1)=1;
phi_step=phi_peak-(phi_peak-phi_res).*(softening);
phi=phi_step;

%Seismic time history
kh=1*acceleration(t);

%Interslice Force
if t==1
   dQ_init=(( W.*(1-kv).*sind(beta_slip) + (W.*kh ).*cosd(beta_slip) - coh.*dl + (-W.*(1-kv).*cosd(beta_slip) + (W.*kh ).*sind(beta_slip) + U).*tand(phi) )...
            ./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) )); 
end
if excesspwp==1
    
Tv=cv.*dt./((Aw./(dx.*2)).^2);
Diss= 1 - (16/(pi^3)).*( (pi-2).*exp((-pi.^2./4).*Tv) + (1/27).*(3.*pi-2).*exp((-9.*pi.^2./4).*Tv) + (1/125).*(5.*pi-2).*exp((-25.*pi.^2./4).*Tv) );
Uexcess=Uexcess-Diss.*Uexcess;
dQ=(( W.*(1-kv).*sind(beta_slip) + (W.*kh ).*cosd(beta_slip) - coh.*dl + (-W.*(1-kv).*cosd(beta_slip) + (W.*kh ).*sind(beta_slip) + U + Uexcess).*tand(phi) )...
            ./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) ));

else
dQ=(( W.*(1-kv).*sind(beta_slip) + (W.*kh ).*cosd(beta_slip) - coh.*dl + (-W.*(1-kv).*cosd(beta_slip) + (W.*kh ).*sind(beta_slip) + U).*tand(phi) )...
            ./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) ));
dQhydro=(( W.*sind(beta_slip) - coh.*dl + (-W.*cosd(beta_slip) + U).*tand(phi) )./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) ))-dQ_init;          

dQres(:,2:end)=el7(:,2:end).*(diff(maxQel,1,2).*el7(:,2:end)-dQ(:,2:end).*el7(:,2:end))-maxdQhydro(:,2:end);
maxdQres=max(cat(3,maxdQres,(dQres).*el7),[],3);
maxdQhydro=max(cat(3,maxdQhydro,(dQhydro).*el7),[],3);
t;
dQ=dQres+dQ+maxdQhydro;









end




plot(xsurf,ysurf,'k'); hold on
plot(xslip,yslip,'r');
axis equal
grid on