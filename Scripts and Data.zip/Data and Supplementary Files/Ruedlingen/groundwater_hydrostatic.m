function[u,dt,t,tinc,infil_actual,cum_infil,Gw] = groundwater_hydrostatic(tinc,depth,inc,infil,ksat,n,alfa,sat,res,theta_avg,limit_inf)

% close all
% clear all
% clc

%limit_inf=0;

%Geometry Domain
%depth=1.0;
%inc=100;
dz=depth/inc;

%Time Domain
%tinc=100;
to=0;
tf=1/infil;500;
dt=(tf-to)/tinc;
t=to+dt:dt:tf;

%Soil Parameters
%n=1.5;
m=1-(1/n);
% alfa=3.6; %1/m
% sat=0.4;
% res=0.05;
gamma_w=9.81; %kN/m
%ksat=0.25/24; %m/hour

%Antecedent Conditions
h0threshold=0; %threshold that represents buildup of saturatation at base of soil column
%theta_avg=0.28; %theta to solve for. This is initial average water content, or the water content being solve for in each time step.

% %Rainfall Parameters
% %infil=1e-1; %infiltration, m/day
% A1=ksat/2; %infiltration regulated by hydraulic conductivity
% dVWC=(sat-theta_avg)/100;
% VWCspace=linspace(theta_avg,sat,100);
% D=((1-m).*ksat/(alfa.*m.*(sat-res))).*(VWCspace.^(0.5-(1./m))).*(((1-VWCspace.^(1/m)).^-m) + ((1-VWCspace.^(1/m)).^m) -2); %VG diffusivity
% S=sqrt(2.*(sat-res).*dVWC.*sum(D)); %sorptivity
% tc=((S.^2).*(2.*infil - A1))./(4.*infil.*((infil-A1).^2));
% tp=(S.^2)./(4*((infil-A1).^2));
% 
% %Calculate Actual Infiltration using Philips (1957) Equation 
% t_noponding=sign(t-tc);
% t_noponding(t_noponding>0)=0;
% t_noponding(t_noponding<0)=1;
% %t_noponding(1)=0;
% t_ponding=sign(t-tc);
% t_ponding(t_ponding<=0)=0;
% t_ponding(t_ponding>0)=1;
% infil_actual=t_noponding.*infil+t_ponding.*(0.5*S.*((t-(tc-tp)).^-0.5) + A1);
% infil_actual(infil_actual>infil)=infil;
% 
% 
% if limit_inf==1
%    infil_actual=infil_actual; 
% else
%    infil_actual=infil.*ones(tinc,1); 
% end

infil_actual=infil.*ones(tinc,1); 
cum_infil=cumsum(infil_actual).*dt;


%Preallocation
h0=logspace(-3,2,inc); %represents the search range for head, each represents a guess that is assessed for closure/convergence
h=h0+linspace(0,depth,inc)'; %discretize head over depth for each guess
z=linspace(0,depth,inc)';
hthreshold=linspace(h0threshold,h0threshold+depth,inc)'; %threshold head for column base becoming saturated

h0crit=zeros(tinc,1);
hbase=zeros(tinc,1);

%tic

for k=1:1:tinc


    dtheta=infil_actual(k).*dt.*depth;
    theta_avg=theta_avg+dtheta;

    %Solve for appropriate head that satisfies average VWC during timestep 
    W=sum(res + (sat-res).*((1+(alfa.*h).^n).^(-m)),1).*dz; %W represents the water height
    theta=W./depth; %volumetric water content at base
    error=(theta-theta_avg).^2; %find difference between goal (average) theta and range of possible SWRCC
    [minerr,minerrloc]=min(error);
    h0crit(k,1)=h0(minerrloc); %critical h0, i.e. potential head at bottom of soil column
%     hcrit(:,k)=res + (sat-res).*((1+(alfa.*(h0crit(k,1)+linspace(0,depth,inc)')).^n).^(-m)); %VWC profile
    
    %threshold that represents onset of saturation at the base of the column (at Z=depth)

    if k==1
    Wthreshold=sum(res + (sat-res).*((1+(alfa.*hthreshold).^n).^(-m))).*dz; %W represents the water height
    theta_threshold=Wthreshold./depth; %threshold water content for base to be saturated
    end
    
subplot(1,2,1)
%if exceeds threshold, calculate standing saturated depth
if theta_avg>=theta_threshold
    hgw(k,1)=((theta_avg-theta_threshold).*depth)./sat;
    hgw(hgw>depth)=depth;
    zcap=z-hgw(k,1);
    zcap(zcap<=0)=0;
    zsat=z-hgw(k,1);
    zsat(zsat>=0)=0;
    hbase(k,1)=0;hgw(k,1);
    hcrit(:,k)=zsat+((res + (sat-res).*((1+(alfa.*(-hbase(k,1)+zcap)).^n).^(-m))).*((-hbase(k,1)+zcap))./sat); %VWC profile
    %hcrit(hcrit(:,k)<-depth,k)=-depth;
    pwpcrit(:,k)=-gamma_w.*hcrit(:,k);
%     plot(pwpcrit(:,k),(z),'b'); hold on; grid on
%     xlabel('Pore Water Pressure [kPa]')
%     ylabel('Soil Height [m]')
    
else
    hbase(k,1)=-h0crit(k,1);
    hgw(k,1)=0;
    hcrit(:,k)=((res + (sat-res).*((1+(alfa.*(-hbase(k,1)+z)).^n).^(-m))).*((-hbase(k,1)+z))./sat); %VWC profile
    pwpcrit(:,k)=-gamma_w.*hcrit(:,k);
%     plot(pwpcrit(:,k),(z),'r'); hold on; grid on
%     xlabel('Pore Water Pressure [kPa]')
%     ylabel('Soil Height [m]')
end

theta_goal_store(k,1)=theta_avg;




% drawnow
% pause(0.01);
end

% subplot(1,2,2)
% plot(t,hgw,'b')
% ylim([0 depth])
% xlim([0 tf])
% xlabel('Time [T]')
% ylabel('Basal Groundwater Height [m]')
% grid on

%toc

u=flipud(pwpcrit);
Gw=hgw;
%Basal Head Plot
% plot(t,hbase,'b')
% grid on

%To do: Add suction stress by multiplying gamma_w by head profile. 
%matrix form



