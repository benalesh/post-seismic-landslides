


profile_plot=0;
disp_comp_plot=1;

%% Infiltration Data
infil_raw=[0	0.030588235
0.183721527	0.039513185
0.303504232	0.020040568
0.367853396	0
0.514979833	0
0.597757105	0.020040568
0.678370754	0.035375254
0.766668998	0.027423935
0.827101257	0.038864097
0.951882679	0.030263692
1.008771071	0.033995943
1.095838288	0.02336714
1.25904269	0.018336714
1.351780094	0.020040568
1.609960131	0.02158215
1.663640391	0.018336714
1.759660535	0.027180527
1.848555641	0.020527383
1.930251102	0.03821501
2.018847777	0.030912779
2.096477116	0.039756592
2.23845562	0.028559838
2.457615817	0.025233266
2.537968338	0
3.016091954	0
3.174819892	0.02515213
3.326721224	0.035537525
3.489179548	0.028884381
3.60120305	0.032535497
3.674057495	0.030993915
3.802979646	0.031399594
3.896127393	0.033995943
4.133118836	0.029452333
4.245254249	0.033346856
4.353659276	0.029127789
4.608071623	0.022474645
4.701741624	0.026206897
4.790711338	0.019716024
4.938882283	0.02198783
5.175873726	0.017444219
5.343218857	0.021419878
5.451735795	0.017444219
5.527201511	0.02158215
5.654780723	0.019066937
5.821044042	0.020689655
6.004206011	0.019066937
6.185763913	0.013955375
6.244741321	0.022231237
6.429880394	0.024908722
6.483262223	0.021014199
6.687985825	0.026288032
6.92393276	0.019472617
7.000927934	0.02693712
7.128805577	0.025070994
7.292494929	0.021095335
7.385791891	0.024016227
7.513594927	0.02198783
7.735776736	0.025233266
8.024284815	0.012738337
8.170963605	0.011764706
8.302310508	0.017444219
8.35640111	0.015091278
8.611820662	0.010628803
8.70459537	0.012413793
8.795728708	0.010628803
8.908311767	0.015496957
9.054132569	0.012657201
9.22032128	0.014117647
9.347490149	0.010709939
9.588137371	0.014117647
9.661103728	0.012819473
9.77178429	0.013549696
9.918500385	0.012657201
10.0693199	0.020689655
10.1591103	0.015983773
10.3106386	0.025557809
10.41993891	0.023286004
10.51263902	0.024908722
10.67588072	0.019959432
10.82423819	0.022636917
10.89731645	0.02158215
11.15586953	0.023935091
11.28423212	0.023123732
11.46881164	0.024584178
11.74489753	0.025070994
11.87326012	0.024259635
12.16777413	0.024827586
12.25890746	0.023042596
12.42565573	0.025720081
12.67984426	0.018580122
12.92220746	0.025720081
13.19314542	0.015010142
13.34426337	0.023691684
13.47072346	0.018742394
13.69361404	0.023529412
13.9481383	0.017119675
14.06046024	0.021419878
14.22217248	0.013144016
14.3352778	0.019148073
14.42615001	0.016795132
14.59480077	0.023610548
14.6838451	0.017281947
14.81082745	0.01346856
14.92132149	0.013793103
];

tinc=100;
to=0;
tf=14.5;
dt=(tf-to)/tinc;
t_rain=to+dt:dt:tf;
infil=interp1(infil_raw(:,1),infil_raw(:,2),t_rain)';
cumulative_rain=cumsum(infil);




%% Profile Plot
if profile_plot==1
    
videoname='ruedlingen_profile.avi';
v = VideoWriter(videoname);
v.Quality = 95;
v.FrameRate=10;
open(v)  

figure;
axis equal
c = colorbar;
c.Label.String = 'Displacement [m]';
c.Location='eastoutside';
caxis([0,0.05]);

for t=1:1:tinc
M=vertcat(dispt(t,1)',dispt(t,:)');
N = length(xsurf);
verts = [xsurf(:), yslip(:)+depth(end,:)'; xslip(:), yslip(:)];

q = (1:N-1)';
faces = [q, q+1, q+N+1, q+N];
p = patch('Faces', faces, 'Vertices', verts, 'FaceVertexCData', [M(:); M(:)], 'FaceColor', 'interp', 'EdgeColor', 'none');
xlabel('X [m]')
ylabel('Y [m]')
colormap jet
grid on


toc

a=text(5,5,strcat('Time=',num2str(round((14.5/100)*(t-1),1)),' hours'),'FontSize',12);
drawnow


frame = getframe(gcf);
writeVideo(v,frame)     
    
delete(a);

end
    close(v)
  

end

%% Time Series Plot
if disp_comp_plot==1

videoname='ruedlingen_comp_v2.avi';
v = VideoWriter(videoname);
v.Quality = 95;
v.FrameRate=10;
open(v)  


for t=1:1:tinc

subplot(3,1,1)
disp_data=[21 0.049
    29 0.0388
    36 0.028];
plot(x(2:end),dispt(t,:),'k'); hold on
scatter(disp_data(:,1),disp_data(:,2),'r','filled')
ylim([0 0.05]);
grid on
xlabel('X [m]')
ylabel('Disp. [m]')
hold off

subplot(3,1,2)
el_compt(el_compt>150)=0;
refine0=sign(el_compt(t,:));
refine=bwmorph(refine0,'shrink',1);
plot(x(2:end),refine.*el_compt(t,:),'r'); hold on
ylim([0 200]);
grid on
xlabel('X [m]')
ylabel('Comp. [kN]')
a=text(5,150,strcat('Time=',num2str(round((14.5/100)*(t-1),1)),' hours'),'FontSize',12);
hold off

subplot(3,1,3)
Qyieldt(Qyieldt<-15)=1;
plot(x(2:end),-Qyieldt(t,:),'r'); hold on;
xlabel('X [m]')
ylabel('Yield [kN]')
grid on
ylim([0 10])
xlim([0 60])
hold off
% 
% subplot(5,1,4)
% 
% %Top
% plot(t_rain(1:t),dispt(1:t,39),'k'); hold on;
% plot(disp_data_real(:,1),disp_data_real(:,2),'k--');
% %Middle
% plot(t_rain(1:t),dispt(1:t,53),'r'); 
% plot(disp_data_real(:,3),disp_data_real(:,4),'r--');
% %Bottom
% plot(t_rain(1:t),dispt(1:t,65),'b');
% plot(disp_data_real(:,5),disp_data_real(:,6),'b--');
% xlabel('Time [hours]')
% ylabel('Disp. [mm]')
% grid on
% ylim([0 0.05])
% xlim([0 14.5])
% hold off
% 
% 
% 
% subplot(5,1,5)
% plot(t_rain(1:t),cumulative_rain(1:t),'b'); hold on
% xlabel('Time [hours]')
% ylabel('Cumul. Rain [mm]')
% grid on
% ylim([-0 2.5])
% xlim([0 14.5])

drawnow
hold off

frame = getframe(gcf);
writeVideo(v,frame)  
delete(a);

end

close(v)

end
