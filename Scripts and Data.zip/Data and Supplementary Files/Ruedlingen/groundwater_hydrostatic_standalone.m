%function[u,dt,t,tinc,infil_actual,cum_infil,Gw] = groundwater_hydrostatic(tinc,depth,inc,infil,ksat,n,alfa,sat,res,theta_avg,limit_inf)

close all
clearvars -except rawsurfdata_geom rawslipdata_geom
clc

import_data=0;

%% Import Geometry
if import_data==1

rawsurfdata_geom=xlsread('ruedlingen_data.xlsx',2,'A2:B23');
rawslipdata_geom=xlsread('ruedlingen_data.xlsx',2,'C2:D32');
end

%% Solver Inputs

%To-do
%transient water response
%fix nonuiform dz and H

%% Discretization
blocks=100;
layers=100;
inc=100;

%% RAW DATA

%depth=[0,0.439435480993076,0.623008275086733,0.806581069180389,0.999946207706181,1.13718948934874,1.27443277099128,1.41167605263384,1.54891933427638,1.71610900719354,1.97431944772260,2.22915390272905,2.48398835773549,2.71854393469140,2.89295119258266,3.06735845047393,3.19734055548231,3.13881539752887,3.01182475852630,2.86766649354778,2.72350822856926,2.62339328014289,2.59461641413627,2.60719634921081,2.66162731691842,2.71605828462603,2.72639242776792,2.70257675804756,2.68250903059235,2.70469905732833,2.67314129006882,2.54311883238862,2.48987525220993,2.48909226858756,2.42631303244893,2.24066653789274,2.06109533541800,1.88152413294326,1.76322898458604,1.80057955973561,1.90669875923696,1.95731006665884,1.94286795358739,1.87509122369350,1.77522052731543,1.71122147845900,1.95582785363171,2.19744944112165,2.52266670237805,2.66310390250450,2.37695713096197,2.11424828449664,1.86529194217199,1.86529194217196,1.86553577155107,1.95185250482762,2.04339088827533,2.13496581493702,2.23665380309847,2.34743255556815,2.63525383967518,2.94788093792691,3.29084550111928,3.52140230039649,3.41672254217716,3.30862912713399,3.18053115244129,2.94822476504192,2.68181382923572,2.41540289342953,2.19862998838386,2.12171720896254,2.04288761964652,1.93600620679756,1.79831153714187,1.66061686748618,1.52292219783048,1.51610612619565,1.55579283599271,1.59547954578977,1.63516625558684,1.81991908899307,2.04652981157606,2.27314053415904,2.97273485740516,3.81627883013557,4.66375030855515,4.41316496413125,4.07154914329126,3.72993332245127,3.60492464755298,3.62684952581531,3.64877440407764,3.66634047036335,3.68133998030158,3.69633949023982,3.70168667554374,3.68466467903192,3.67450499166848,3.66434530430504,3.65418561694160];
depth=2;

infil_raw=[0	0.030588235
0.183721527	0.039513185
0.303504232	0.020040568
0.367853396	0
0.514979833	0
0.597757105	0.020040568
0.678370754	0.035375254
0.766668998	0.027423935
0.827101257	0.038864097
0.951882679	0.030263692
1.008771071	0.033995943
1.095838288	0.02336714
1.25904269	0.018336714
1.351780094	0.020040568
1.609960131	0.02158215
1.663640391	0.018336714
1.759660535	0.027180527
1.848555641	0.020527383
1.930251102	0.03821501
2.018847777	0.030912779
2.096477116	0.039756592
2.23845562	0.028559838
2.457615817	0.025233266
2.537968338	0
3.016091954	0
3.174819892	0.02515213
3.326721224	0.035537525
3.489179548	0.028884381
3.60120305	0.032535497
3.674057495	0.030993915
3.802979646	0.031399594
3.896127393	0.033995943
4.133118836	0.029452333
4.245254249	0.033346856
4.353659276	0.029127789
4.608071623	0.022474645
4.701741624	0.026206897
4.790711338	0.019716024
4.938882283	0.02198783
5.175873726	0.017444219
5.343218857	0.021419878
5.451735795	0.017444219
5.527201511	0.02158215
5.654780723	0.019066937
5.821044042	0.020689655
6.004206011	0.019066937
6.185763913	0.013955375
6.244741321	0.022231237
6.429880394	0.024908722
6.483262223	0.021014199
6.687985825	0.026288032
6.92393276	0.019472617
7.000927934	0.02693712
7.128805577	0.025070994
7.292494929	0.021095335
7.385791891	0.024016227
7.513594927	0.02198783
7.735776736	0.025233266
8.024284815	0.012738337
8.170963605	0.011764706
8.302310508	0.017444219
8.35640111	0.015091278
8.611820662	0.010628803
8.70459537	0.012413793
8.795728708	0.010628803
8.908311767	0.015496957
9.054132569	0.012657201
9.22032128	0.014117647
9.347490149	0.010709939
9.588137371	0.014117647
9.661103728	0.012819473
9.77178429	0.013549696
9.918500385	0.012657201
10.0693199	0.020689655
10.1591103	0.015983773
10.3106386	0.025557809
10.41993891	0.023286004
10.51263902	0.024908722
10.67588072	0.019959432
10.82423819	0.022636917
10.89731645	0.02158215
11.15586953	0.023935091
11.28423212	0.023123732
11.46881164	0.024584178
11.74489753	0.025070994
11.87326012	0.024259635
12.16777413	0.024827586
12.25890746	0.023042596
12.42565573	0.025720081
12.67984426	0.018580122
12.92220746	0.025720081
13.19314542	0.015010142
13.34426337	0.023691684
13.47072346	0.018742394
13.69361404	0.023529412
13.9481383	0.017119675
14.06046024	0.021419878
14.22217248	0.013144016
14.3352778	0.019148073
14.42615001	0.016795132
14.59480077	0.023610548
14.6838451	0.017281947
14.81082745	0.01346856
14.92132149	0.013793103
];

%% PROCESS DATA
%Raw Data
xmax=56.5;
slices=100;
x=linspace(0,xmax,blocks+1);
xsurf0=rawsurfdata_geom(:,1);
ysurf0=rawsurfdata_geom(:,2);
xslip0=rawslipdata_geom(:,1);
yslip0=rawslipdata_geom(:,2);

%Interpolate Geometric Data
xsurf=x;
ysurf=interp1(xsurf0,ysurf0,x);
xslip=x;
yslip=interp1(xslip0,yslip0,x);
ysurf(1)=36.5;
yslip(1)=36.5;
beta_surf=-atand(diff(ysurf)./diff(xsurf));
beta_slip=-atand(diff(yslip)./diff(xslip));
beta=beta_slip;
theta=beta_slip;

%Depth of Soil Mantle
dx=xmax/blocks;
Ho=ysurf-yslip;
H=Ho(:,2:end);
depth=H;
dl=dx./cosd(beta_slip);
A=dx.*0.5.*(ysurf(:,1:end-1)-yslip(:,1:end-1)+ysurf(:,2:end)-yslip(:,2:end)); %Area of Slice
dz=depth/layers;

%% 
%Geometry Domain
%depth=1.0;

%dz=depth/inc;

figure(1)
%Time Domain
tinc=100;
to=0;
tf=14.5;
dt=(tf-to)/tinc;
t=to+dt:dt:tf;

%Soil Parameters
n=1.78;
alfa=7.85; %1/m
sat=0.47;
res=0.1551;
m=1-(1/n);
ksat=3.6e-3; %m/hour
gamma_w=9.81; %kN/m
theta_avg=0.25*ones(1,blocks); %initial average water content
theta_avg=0.28*linspace(1,1,blocks); %initial average water content

limit_inf=0; %limit infiltration

infil=interp1(infil_raw(:,1),infil_raw(:,2),t)';
%infil(1)=0;



%Modify Rainfall to Describe Variable Rainfall alonf Length
zone1=find(xslip>9.4 & xslip<20.6);
zone2=find(xslip>20.6 & xslip<50.7);

infil_actual=zeros(blocks,tinc);

infil_actual(:,zone1)=repmat(infil,1,length(zone1));
infil_actual(:,zone2)=repmat(infil/4,1,length(zone2));


%% Preallocation
h0=logspace(-3,2,inc); %represents the search range for head, each represents a guess that is assessed for closure/convergence
z=(linspace(0.01,1,layers)').*Ho(2:end);
h0threshold=0; %threshold that represents buildup of saturatation at base of soil column


h0crit=zeros(tinc,1);
hbase=zeros(tinc,1);

dL=dx./cosd(beta_slip);
dbase=-diff(yslip);
Qin=zeros(blocks,1)';
Qout=zeros(blocks,1)';
Q=zeros(blocks,1)';

tic
%% Solver
for k=1:1:tinc


%     %calculate darcy flow
%     if j>1
%     flowon=sign(hgw(k-1,:));    
%     posgw=sign(hgw(k-1,:));
%     
%     i_hyd=(diff(hgw(k-1,:))+dbase(2:end))./(dx./cosd(beta_slip(2:end)));   
%     Qout=horzcat(1*ksat.*i_hyd.*hgw(k-1,1:end-1),0);
%     Qin=horzcat(0,1*ksat.*i_hyd.*hgw(k-1,2:end));
%     
%     Q=1*(posgw.*(Qin-Qout).*dt./(depth.*dx));
% 
%     end
    

    %calculate darcy flow
    
    dbase=horzcat(-diff(yslip));
    if j>1
    posgw=sign(hgw(k-1,:));
    htemp=dbase+hgw(k-1,:);    
    Ltemp=dx./cosd(beta_slip(1:end));
    i_hyd=htemp./Ltemp; 
    Qchange=1*ksat.*i_hyd.*hgw(k-1,:);
    
    Qin(2:end)=Qchange(1:end-1); %flowing into cells
    Qout(1:end-1)=Qchange(1:end-1);
    Qout(end)=1e-2;
    Q=Qin-Qout; %need to fix this for hieght of total column!

    end


for j=1:1:blocks
    
    dtheta=infil_actual(k,j).*dt./depth(1,j);
    theta_avg(1,j)=theta_avg(1,j)+dtheta+Q(1,j);
    
    h=h0+z(:,j);%discretize head over depth for each guess    
        
    %Solve for appropriate head that satisfies average VWC during timestep 
    W=sum(res + (sat-res).*((1+(alfa.*h).^n).^(-m)),1).*dz(1,j); %W represents the water height
    theta=W./depth(1,j); %volumetric water content at base
    error=(theta-theta_avg(1,j)).^2; %find difference between goal (average) theta and range of possible SWRCC
    [minerr,minerrloc]=min(error);
    h0crit(k,j)=h0(minerrloc); %critical h0, i.e. potential head at bottom of soil column

    %threshold that represents onset of saturation at the base of the column (at Z=depth)

    if k==1
    hthreshold=h0threshold+z(:,j);
    Wthreshold(1,j)=sum(res + (sat-res).*((1+(alfa.*hthreshold).^n).^(-m)),1).*dz(1,j); %W represents the water height
    theta_threshold(1,j)=Wthreshold(1,j)./depth(1,j); %threshold water content for base to be saturated
    end
    
%     if j==18
%         1111
%     end
    
if theta_avg(1,j)>=theta_threshold(1,j)
    %hgw(k,j)=((theta_avg(1,j)-theta_threshold(1,j)).*depth(1,j))./sat;
    
    %Solution Space
    depthsat_lin=linspace(0,depth(1,j),inc)'-linspace(0,20,1000);
    depthsat_lin(depthsat_lin<0)=0;
    depthsat=linspace(0,20,1000);
    
    %find VWC profile with saturated portion that yields appropriate average water content
    theta_hold=res + (sat-res).*((1+(alfa.*depthsat_lin).^n).^(-m));
    mean_theta=mean(theta_hold,1);
    error=(mean_theta-theta_avg(1,j)).^2; %find difference between goal (average) theta and range of possible SWRCC
    [minerr_surf,minerrloc]=min(error);
    %get saturated depth and height of capillary layer
    hgw(k,j)=depthsat(minerrloc); %groundwater height
    
    
    if hgw(k,j)>depth(1,j)
        hgw(k,j)=depth(1,j);
    end
    
    zcap=z(:,j)-hgw(k,j);
    zcap(zcap<=0)=0;
    zsat=z(:,j)-hgw(k,j);
    zsat(zsat>=0)=0;
    hbase(k,j)=0;%hgw(k,1);
    hcrit(:,j)=zsat+((res + (sat-res).*((1+(alfa.*(-hbase(k,j)+zcap)).^n).^(-m))).*((-hbase(k,j)+zcap))./sat); %VWC profile
    pwpcrit(:,j)=-gamma_w.*hcrit(:,j);
    VWC_crit(:,j)=res + (sat-res).*((1+(alfa.*(zcap)).^n).^(-m));
    
%     plot(pwpcrit(:,k),(z),'b'); hold on; grid on
%     xlabel('Pore Water Pressure [kPa]')
%     ylabel('Soil Height [m]')
    
else
    hbase(k,j)=-h0crit(k,j);
    hgw(k,j)=0;
    hcrit(:,j)=((res + (sat-res).*((1+(alfa.*(-hbase(k,j)+z(:,j))).^n).^(-m))).*((-hbase(k,j)+z(:,j)))./sat); %VWC profile
    pwpcrit(:,j)=-gamma_w.*hcrit(:,j);
    VWC_crit(:,j)=res + (sat-res).*((1+(alfa.*(-hbase(k,j)+z(:,j))).^n).^(-m));
%     plot(pwpcrit(:,k),(z),'r'); hold on; grid on
%     xlabel('Pore Water Pressure [kPa]')
%     ylabel('Soil Height [m]')
end




    
end

theta_avg_t(k,:)=theta_avg;
% VWC_CL3(k,1)=VWC_crit(50,100-64);  %VWC at 0.9 m depth
% VWC_CL2(k,1)=VWC_crit(31,100-57);  %VWC at 0.9 m depth
% VWC_CL1(k,1)=VWC_crit(45,100-70);  %VWC at 0.9 m depth
VWC_CL3(k,1)=pwpcrit(100-64,38);  %VWC at 0.9 m depth
VWC_CL2(k,1)=pwpcrit(100-57,52);  %VWC at 0.9 m depth
VWC_CL1(k,1)=pwpcrit(100-70,69);  %VWC at 0.9 m depth

% VWC_CL3(k,1)=VWC_crit(50,38);  %VWC at 0.9 m depth
% VWC_CL2(k,1)=VWC_crit(49,52);  %VWC at 0.9 m depth
% VWC_CL1(k,1)=VWC_crit(27,68);  %VWC at 0.9 m depth
% VWC_CL3(k,1)=VWC_crit(32,38);  %VWC at 0.9 m depth
% VWC_CL2(k,1)=VWC_crit(35,52);  %VWC at 0.9 m depth
% VWC_CL1(k,1)=VWC_crit(50,69);  %VWC at 0.9 m depth


k

%%     
% subplot(1,2,1)
% %if exceeds threshold, calculate standing saturated depth
% if theta_avg>=theta_threshold
%     hgw(k,1)=((theta_avg-theta_threshold).*depth)./sat;
%     hgw(hgw>depth)=depth;
%     zcap=z-hgw(k,1);
%     zcap(zcap<=0)=0;
%     zsat=z-hgw(k,1);
%     zsat(zsat>=0)=0;
%     hbase(k,1)=0;hgw(k,1);
%     hcrit(:,k)=zsat+((res + (sat-res).*((1+(alfa.*(-hbase(k,1)+zcap)).^n).^(-m))).*((-hbase(k,1)+zcap))./sat); %VWC profile
%     %hcrit(hcrit(:,k)<-depth,k)=-depth;
%     pwpcrit(:,k)=-gamma_w.*hcrit(:,k);
%     plot(pwpcrit(:,k),(z),'b'); hold on; grid on
%     xlabel('Pore Water Pressure [kPa]')
%     ylabel('Soil Height [m]')
%     
% else
%     hbase(k,1)=-h0crit(k,1);
%     hgw(k,1)=0;
%     hcrit(:,k)=((res + (sat-res).*((1+(alfa.*(-hbase(k,1)+z)).^n).^(-m))).*((-hbase(k,1)+z))./sat); %VWC profile
%     pwpcrit(:,k)=-gamma_w.*hcrit(:,k);
%     plot(pwpcrit(:,k),(z),'r'); hold on; grid on
%     xlabel('Pore Water Pressure [kPa]')
%     ylabel('Soil Height [m]')
% end
%%

if mod(k,10)==0
    subplot(1,3,[1 2])
   plot(xsurf,ysurf,'k'); hold on
plot(xslip,yslip,'r');
plot(xslip(2:end),yslip(2:end)+hgw(end,:),'b--');
%axis equal
grid on 
    drawnow
    
    subplot(1,3,3)
plot(VWC_CL3,'b'); hold on
plot(VWC_CL2,'g'); hold on
plot(VWC_CL1,'r'); hold on
drawnow
pause(0.01);
end


theta_goal_store=theta_avg;



pwpout(:,:,k)=flipud(pwpcrit);


end

figure(2);
plot(VWC_CL3,'b'); hold on
plot(VWC_CL2,'g'); hold on
plot(VWC_CL1,'r'); hold on

save('ruedlingen_pwp.mat','pwpout');



