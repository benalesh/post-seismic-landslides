clearvars -except rawsurfdata_geom rawslipdata_geom
close all

import_data=0;
%% Import Geometry
if import_data==1

rawsurfdata_geom=xlsread('ruedlingen_data.xlsx',2,'A2:B23');
rawslipdata_geom=xlsread('ruedlingen_data.xlsx',2,'C2:D32');
end

%% Solver Inputs

%To-do
%transient water response
%fix nonuiform dz and H

%% Discretization
blocks=100;
layers=100;

%% SOIL PARAMETERS
phi_peak=38*ones(1,blocks); %peak friction angle, � 33
phi_res=32.5*ones(1,blocks); %residual friction angle, � 39
res_strain=0.01; %residual shear strain, in absolute numbers (not percent)
coh=3; %cohesion, kPa

eta=0e1; %dynamic viscosity, kPas/m
gamma=17; %unit weight of soil
gamma_w=9.81; %unit weight of water
E=2.5e4; %young's modulus of soil, kPa
poisson=0.3; %poisson's ratio
Askempton=0.5;

%Root Parameters
Er=0.000001e1; %young's modulus of roots, kPa
%root_tens=40; %root yield, kN

%% RFBM Root properties, Norway Spruce
%Number of Roots
NR=100; %29
Pdisc=1000;

%% Hydrologic Parameters
q=0; %infiltration of rainfall
inz=0;
n=1.78;
alfa=7.85; %1/m
sat=0.47;
res=0.1551;
gamma_w=9.81; %kN/m
ksat=3e-3; %m/hour
theta_avg=0.25; %initial average water content
limit_inf=0; %limit infiltration 
cv=ksat.*10;
excesspwp=0;

%% Time parameters
tinc=100;
dt=1;

%% Seismic time history
kh=0;
kv=0;


%% PROCESS DATA
%Raw Data
xmax=56.5;
slices=100;
x=linspace(0,xmax,blocks+1);
xsurf0=rawsurfdata_geom(:,1);
ysurf0=rawsurfdata_geom(:,2);
xslip0=rawslipdata_geom(:,1);
yslip0=rawslipdata_geom(:,2);

%Interpolate Geometric Data
xsurf=x;
ysurf=interp1(xsurf0,ysurf0,x);
xslip=x;
yslip=interp1(xslip0,yslip0,x);
ysurf(1)=36.5;
yslip(1)=36.5;
beta_surf=-atand(diff(ysurf)./diff(xsurf));
beta_slip=-atand(diff(yslip)./diff(xslip));
beta=beta_slip;
theta=beta_slip;

%Depth of Soil Mantle
dx=xmax/blocks;
Ho=ysurf-yslip;
H=Ho(:,2:end);
depth=(linspace(0.01,1,layers)').*Ho;
dl=dx./cosd(beta_slip);
A=dx.*0.5.*(ysurf(:,1:end-1)-yslip(:,1:end-1)+ysurf(:,2:end)-yslip(:,2:end)); %Area of Slice
dz=H/layers;

%Calculate forces for force equilibrium
W=(A*gamma); %Weight of Slice

%Calclate Hydrologic Profile
%[u,dt,t,tincGw,infil_actual,cum_infil,Gw] = groundwater_hydrostatic(1,Ho,layers,inz,ksat,n,alfa,sat,res,theta_avg,limit_inf);
% U=u.*dx./cosd(beta(:,1:end)); %Resultant of PWP in Slice

load('ruedlingen_pwp.mat');

%U=-1+-5.*flipud(depth(:,2:end))./cosd(beta(:,1:end)); %Resultant of PWP in Slice

%% Preprocessing
%Initialize System
test=zeros(layers,blocks);
accel=zeros(layers,blocks);
vel=zeros(layers,blocks);
comp=zeros(layers,blocks);
tens=zeros(layers,blocks);
lat_comp=zeros(layers,blocks);
d_disp=zeros(layers,blocks);
disp_net=zeros(layers,blocks);
disp_profile=zeros(layers,blocks);
disp_step=zeros(layers,blocks);
disp_total=zeros(layers,blocks);
dQ=zeros(layers,blocks);
dQel=zeros(layers,blocks);
dQvisc=zeros(layers,blocks);
dQroots=zeros(layers,blocks);
dQres=zeros(layers,blocks);
dQres_hold=zeros(layers,blocks);
el7=zeros(layers,blocks);
Q=zeros(layers,blocks);
Qres=zeros(layers,blocks);
Uexcess=zeros(layers,blocks);
shear_strain=zeros(layers,blocks);
press_un=zeros(layers,blocks);
press_tri=zeros(layers,blocks);
disp_el=zeros(layers,blocks);
disp_visc=zeros(layers,blocks);
residual=zeros(layers,blocks);
residualpos=zeros(layers,blocks);
residualneg=zeros(layers,blocks);
Qel=zeros(layers,blocks);
Qroots=zeros(layers,blocks);
Qvisc=zeros(layers,blocks);
root_yield=ones(layers,blocks);
maxQel=zeros(layers,blocks);
maxdQres=zeros(layers,blocks);
maxdQhydro=zeros(layers,blocks);
maxQ=zeros(layers,blocks);
maxelcomp=zeros(layers,blocks);
posQel=zeros(layers,blocks);
negQel=zeros(layers,blocks);
phi_step=zeros(layers,blocks);
el_strain=zeros(layers,blocks);
heave=zeros(layers,blocks);
dispt=zeros(tinc,blocks);
velt=zeros(tinc,blocks);
accelt=zeros(tinc,blocks);
compt=zeros(tinc,blocks);
el_compt=zeros(tinc,blocks);
sbt_lengtht=zeros(tinc,1);
maxdispt=zeros(tinc,1);
maxvelt=zeros(tinc,1);
maxaccelt=zeros(tinc,1);
maxcompt=zeros(tinc,1);
maxelcompt=zeros(tinc,1);

%% Solver
tic

for t=1:1:tinc
    
U=pwpout(:,:,t).*dx./cosd(beta_slip);
%Preallocation of time-dependent data    
disp_diff=zeros(layers,blocks);

%Softening Function
softening=abs(shear_strain)./res_strain;
softening(softening>1)=1;
phi_step=phi_peak-(phi_peak-phi_res).*(softening);
phi=phi_step;


%Interslice Force
if t==1
   dQ_init=(( W.*(1-kv).*sind(beta_slip) + (W.*kh ).*cosd(beta_slip) - coh.*dl + (-W.*(1-kv).*cosd(beta_slip) + (W.*kh ).*sind(beta_slip) + U).*tand(phi) )...
            ./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) )); 
end
if excesspwp==1
    
Tv=cv.*dt./((Aw./(dx.*2)).^2);
Diss= 1 - (16/(pi^3)).*( (pi-2).*exp((-pi.^2./4).*Tv) + (1/27).*(3.*pi-2).*exp((-9.*pi.^2./4).*Tv) + (1/125).*(5.*pi-2).*exp((-25.*pi.^2./4).*Tv) );
Uexcess=Uexcess-Diss.*Uexcess;
dQ=(( W.*(1-kv).*sind(beta_slip) + (W.*kh ).*cosd(beta_slip) - coh.*dl + (-W.*(1-kv).*cosd(beta_slip) + (W.*kh ).*sind(beta_slip) + U + Uexcess).*tand(phi) )...
            ./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) ));

else
dQ=(( W.*(1-kv).*sind(beta_slip) + (W.*kh ).*cosd(beta_slip) - coh.*dl + (-W.*(1-kv).*cosd(beta_slip) + (W.*kh ).*sind(beta_slip) + U).*tand(phi) )...
            ./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) ));
dQhydro=0*((( W.*sind(beta_slip) - coh.*dl + (-W.*cosd(beta_slip) + U).*tand(phi) )./ ( (cosd(beta_slip-theta) + sind(beta_slip-theta).*tand(phi)) ))-dQ_init);          

dQres(:,2:end)=0*el7(:,2:end).*(diff(maxQel,1,2).*el7(:,2:end)-dQ(:,2:end).*el7(:,2:end))-maxdQhydro(:,2:end);
maxdQres=max(cat(3,maxdQres,(dQres).*el7),[],3);
maxdQhydro=max(cat(3,maxdQhydro,(dQhydro).*el7),[],3);
t;
dQ=dQres+dQ+maxdQhydro;

end



%find limit of zone 1, dictated by roots, downdrag  
el1=sign(dQ);
el1(el1<0)=0;
el1=-cumsum(el1,2);
el1(el1(:,end)==0,:)=-1;
el1(el1==0)=1;
el1(el1<0)=0;

%find zone 2, dictated by soil+roots, soil shear
el2=sign(dQ);
el2(el2<0)=0;



%find zone 3, dictated by soil ploughing
el3=sign(dQ);
el3(el3<0)=0;
el3=cumsum(el3,2);
el3(el3>0)=1;

%find zone 4, root mobilization
compr=(Er/(E+Er)).*el2.*cumsum(el2.*dQ,2,'reverse'); %mobilization of root tension in unstable zone
tensr=el1.*cumsum(el1.*dQ,2,'reverse'); %mobilization of root tension (downdrag) in headscarp
maxcompr=max(compr,[],2); %this needs to handle history of root tension
el4=el1.*(tensr+maxcompr); %difference of max value to find upslope cutoff of root tension
el4(el4<0)=0;
el4(el4>0)=1;
el5=el4+el3;

%Need to account for deformation of root zone separately than compression

%find compression profile
dcomp1=(el3-el2).*dQ; %ploughing zone
dcomp2=el2.*dQ; %unstable zone
dcomp3=el4.*dQ; %root tension zone
dcomp4=(Er/(E+Er)).*el2.*dQ;  %root resistance in unstable zone
dcomp5=0*dQhydro.*el3;
% dcomp=dcomp1+dcomp2-dcomp3-dcomp4; %differential compression profile
%dcomp=dcomp1+dcomp2-dcomp4; %differential compression profile
dcomp=dcomp1+dcomp2-dcomp4+dcomp5; %differential compression profile


comp=cumsum(dcomp,2); %full compression profile
comp(comp<0)=0; %no soil tension considered



if t==1
    comp_init=comp;
end

% %find residual stresses and replace time-dependent compression values that are lower    

residual=maxQel-comp; %residual compression
%residual=maxQel; %residual compressio
residual(residual<0)=0;
add_hydro=sign(residual);
test2=0*add_hydro.*(cumsum(add_hydro.*dQhydro,2,'reverse'));
%comp=comp+residual; %add residual compression


%assess root failure
Qroots=el2.*cumsum(dcomp4,2,'reverse');

% root_yield=sign(root_tens-Qroots);
% if min(min(root_yield))<=0 && Er>0
%     Er=0;
%     t_rootfail=t;
% end

%find zone 4, where total compression is positive
%el6=sign(comp);
el6=abs(sign(comp));

%find effective stiffness throughout mantle
% Edist=E+root_yield.*Er; %effective stiffness
Edist=E+Er; %effective stiffness

%Strain Energy and Displacement Profile
lat_comp=el6.*dx.*cumsum(comp.*cosd(theta) - el_strain.*Edist.*H ,2,'reverse','omitnan')+0*add_hydro.*(cumsum(add_hydro.*dQhydro,2,'reverse'));
el_comp=lat_comp./(1+ el6.*dx.*cumsum((el6.*eta.*dl)./(Edist.*H.*dt.*dz),2,'reverse'));

%Calculate Elastic and Viscous Compressive Force Components
Qel(:,1:end-1)=-(1/dx).*diff(el_comp + el6.*dx.*cumsum(el_strain.*Edist.*H,2,'reverse','omitnan'),1,2)./cosd(theta(:,1:end-1));
Qel=Qel.*el6; %effective compression realized
Qvisc=comp-Qel; %force from viscous resistance
%Qvisc(Qvisc<0)=0;
% dQel(:,1:end-1)=diff(Qel,1,2);
% dQel(:,2:end)=dQel(:,1:end-1).*el6(:,1:end-1);


%Displacement components from compression and viscosity
disp_net=el_comp./(Edist.*H); %net compressive displacement profile during timestep
disp_el=lat_comp./(Edist.*H); %max elastic compressive displacement along soil mantle
disp_visc=disp_el-disp_net; %compressive displacement resisted from viscosity along soil mantle

%Displacement and Strains
disp_diff(:,1:end-1)=-diff(disp_net,1,2); %calculate differential displacement 
disp_diff=disp_diff.*el6; %differential displacement realized
disp_step=disp_step+disp_diff; %total differential displacement at end of step
disp_total=disp_total+disp_net; %total compressive displacement profile during timestep
shear_strain=disp_total.*dz; %shear strain within layer
el_strain=disp_step./dx; %compressive strain within layer
%heave=el_strain.*poisson.*Ho; %vertical heave (m) throughout profile

dQel(:,1:end-1)=diff(el_strain.*Edist.*H,1,2)./cosd(theta(:,1:end-1));
dQel(:,2:end)=dQel(:,1:end-1).*el6(:,1:end-1);


el7=sign(el_strain);
el7(el7<0)=0;


dQvisc(:,1:end-1)=diff(Qvisc,1,2);
dQvisc(:,2:end)=dQvisc(:,1:end-1).*el7(:,1:end-1);
dQvisc(dQvisc<0)=0;


%Store Previous Data for Change Assessment
disp_profile_previous=disp_profile;
vel_profile_previous=vel;

%maximum elastic compression throughout analysis
maxQel=max(cat(3,maxQel,Qel),[],3);
maxQel=maxQel.*el6;

maxQ=(Qvisc-maxQel).*el7;


%Find incremental residual compression 
% dQres_hold(:,2:end)=diff(maxQel,1,2)-dQ_init(:,2:end).*el6(:,2:end);
dQres_hold(:,2:end)=diff(maxQel,1,2).*el7(:,2:end)-dQ_init(:,2:end).*el7(:,2:end);
%dQres_hold(:,2:end)=diff(maxQel,1,2);
dQres_hold(:,2:end)=diff(residual,1,2);
%dQres=max(cat(3,dQres,dQres_hold),[],3);
% dQres_hold(:,2:end)=diff(maxQel-comp,1,2);
% dQres(:,2:end)=dQres(:,1:end-1).*el6(:,1:end-1);

%Calculate Cumulative Displacement Profile
d_disp(2:end,:)=diff(disp_total,1); %find incremental displacement stemming from each layer with depth
disp_profile=cumsum(d_disp,1,'reverse'); %displacement profile

%RFBM Mobilization
root_disp=max(max(disp_profile));

[Troot,meanF_u,meanF_w,meanF_l,PR_u,PR_w,PR_l,Fa,Fb,mF,kF,muF,sigF]= rfbm_initialize(Pdisc,NR,root_disp);
Troot_t(t,1)=Troot;
if root_disp==0
Er=Er;
else
AA=2;
Er=(Troot./AA)./(max(max(disp_profile))./dx);
end

%Calculate Shear Band Width and Length along Slope Length
sbt_width=dz.*sum(sign(disp_total),1);
sbt_lengtht(t,1)=dx*sum(sign(sum(sign(disp_total),1)));

%Calculate Velocity and Acceleration Profile Time Series
vel=(disp_profile-disp_profile_previous)/dt;
accel=(vel-vel_profile_previous)/dt;   

%yield
kp=real((cosd(phi).^2)./((1-sqrt( (sind(phi).*(sind(phi_peak-beta)))./(cosd(-beta)))).^2));
Qyield=gamma.*depth(:,1:end-1).*depth(:,1:end-1).*kp;

%volume change
dV=el_strain.*poisson;
Uexcess=Uexcess+Askempton.*el_comp./H;

%Store Time Series of Landslide Behavior
dispt(t,:)=disp_profile(1,:);
velt(t,:)=vel(1,:);
accelt(t,:)=accel(1,:);
compt(t,:)=comp(end,:);
el_compt(t,:)=Qel(end,:);
maxdispt(t,1)=max(dispt(t,:));
maxvelt(t,1)=max(velt(t,:));
maxaccelt(t,1)=max(accelt(t,:));
maxcompt(t,1)=max(compt(t,:));
maxelcompt(t,1)=max(el_compt(t,:));
Qyieldt(t,:)=Qyield(end,:)-el_compt(t,:)-(mean(pwpout(:,:,t),1).*depth(end,1:end-1))./(cosd(45+0.5*phi(end,:)).^2);
Qrootst(t,:)=Qroots(end,:);
dQrest(t,:)=dQres(end,:);


subplot(2,1,1)
disp_data=[21 0.049
    29 0.0388
    36 0.028];
plot(x(2:end),dispt(t,:),'k'); hold on
scatter(disp_data(:,1),disp_data(:,2),'r','filled')
ylim([0 0.05]);
grid on
xlabel('X [m]')
ylabel('Displacement [cm]')
hold off

subplot(2,1,2)
refine0=sign(el_compt(t,:));
refine=bwmorph(refine0,'shrink',1);
plot(x(2:end),refine.*el_compt(t,:),'k'); hold on
ylim([0 0.05]);
ylim([0 200]);
grid on
xlabel('X [m]')
ylabel('Compression [kN]')


drawnow
pause(0.001)
hold off
toc
end



% subplot(2,1,1)
% plot(xsurf,ysurf,'k'); hold on
% plot(xslip,yslip,'r');
% %axis equal
% grid on


% plot(x(2:end),dispt(end,:),'k'); hold on
% disp_data=[21 0.049
%     29 0.0388
%     36 0.028];
% ylim([0 0.05]);
% drawnow



%% TIME PLOT

figure;
disp_data_real=[0	0	0	0	0	0
9.029191555	1.46172E-07	9.02236264	1.16009E-08	9.04372974	2.78422E-08
9.539903902	0.001879204	9.67487782	0.000835255	9.568560662	0.000208789
10.05059157	0.003132104	10.34869428	0.002296972	10.09338336	0.000208789
10.60384888	0.004802638	11.07213144	0.003132239	10.56855243	2.78422E-08
11.00106959	0.006264355	11.68918563	0.003967506	11.12888549	0.001252872
11.47626335	0.006681988	12.43392408	0.005429223	11.66083329	0.002088139
12.0649652	0.007934889	12.99427358	0.007099756	12.15026082	0.003758673
12.54016719	0.008561339	13.38448438	0.01064964	12.60421912	0.00522039
12.85937371	0.010023056	13.74640865	0.016287691	13.08659558	0.007935007
13.14315216	0.012320039	14.17946883	0.027354977	13.49804183	0.010440807
13.51917856	0.015869923	14.50616248	0.038839896	13.93793915	0.015034775
13.76768524	0.022969691	14.85411627	0.049907181	14.37085946	0.022552176
14.03040101	0.03069591	15.08149446	0.06076565	14.65485182	0.030278394
14.25066232	0.040927928	15.20253081	0.072668202	15.02397525	0.038631063
14.42829639	0.049280596	15.29560152	0.094802773	15.20150236	0.044269114
14.60594692	0.058050898	15.33912557	0.119443144	15.31559461	0.059930367
14.78363035	0.067656466	15.38295404	0.151809733	15.38039525	0.084570738
14.94006187	0.077888485	14.94006187	0.071206485	14.94006187	0.068909485
15.06093367	0.085614703	15.06093367	0.078932703	15.06093367	0.076635703
15.10399697	0.098561339	15.10399697	0.091879339	15.10399697	0.089582339
15.17559362	0.115684309	15.17559362	0.109002309	15.17559362	0.106705309
15.24015567	0.134268995	15.24015567	0.127586995	15.24015567	0.125289995
15.26948709	0.15870055	15.26948709	0.15201855	15.26948709	0.14972155
];

time_series=linspace(0,14.5,100);
%Top
plot(time_series,dispt(:,39),'k'); hold on;
plot(disp_data_real(:,1),disp_data_real(:,2),'k--');
%Middle
plot(time_series,dispt(:,53),'r'); hold on;
plot(disp_data_real(:,3),disp_data_real(:,4),'r--');
%Bottom
plot(time_series,dispt(:,65),'b'); hold on;
plot(disp_data_real(:,5),disp_data_real(:,6),'b--');





%% PROFILE PLOT

%Displacement Contours
figure

M=vertcat(dispt(end,1)',dispt(end,:)');
N = length(xsurf);
verts = [xsurf(:), yslip(:)+depth(end,:)'; xslip(:), yslip(:)];

q = (1:N-1)';
faces = [q, q+1, q+N+1, q+N];
p = patch('Faces', faces, 'Vertices', verts, 'FaceVertexCData', [M(:); M(:)], 'FaceColor', 'interp', 'EdgeColor', 'none');
xlabel('X [m]')
ylabel('Y [m]')
colormap jet
grid on
hold on

toc


axis equal
c = colorbar;
c.Label.String = 'Displacement [m]';
c.Location='east';


