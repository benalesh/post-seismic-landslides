tic;
%close all;
clear all;


%% Soil Properties
gam_soil=20;
gam_w=9.81;
phi=35;
coh=00;

%% Sliding Block Properties
m=0.20;
H=2;
L=1;
slope=30;

%% Seismic Properties
amplify=2;
kv=0.0;
%Get Motion
[motion]=amplify*extract_motion;
time=motion(:,1);
kh=motion(:,2);
no_increments=length(motion);
time_increment=motion(2,1);

%% Root properties, Norway Spruce

%Number of Roots
NR=1000; %29



%% Probability Discretization

Pdisc=1000;

%% Root Diameter Probability Function

[meanF_u,meanF_w,meanF_l,PR_u,PR_w,PR_l,Fa,Fb,mF,kF,muF,sigF] = root_pdf(Pdisc,kappa,Wo,lambda,Fo,NR);

%% Root Force Probability Function


% disp_c=1; %displacement that causes root rupture
% 
% %basal root resistance
% b_shear_band_z=0.01;
% b_shear_strain=disp/b_shear_band_z;
% b_distortion=atand(b_shear_strain);
% 
% %side root resistance
% s_shear_band_z=0.01;
% s_shear_strain=disp/s_shear_band_z;
% s_distortion=atand(s_shear_strain);

%head shear resistance

W=H*L*gam_soil;
Ub=(m*H*L/cosd(slope))*gam_w;


% FS=(coh*L +(W*cosd(slope)-kh*W*sind(slope)-kv*W*cosd(slope)+Tr-Ub)*tand(phi))/...
%     (kh*W*cosd(slope)+W*(1-kv)*sind(slope));

%% Newmark Analysis

color_test={'k','r','b'};
NR=[0; 500; 1000];


for j=1:1:3

%Initialize Motion
vel(:,j)=zeros(no_increments,1);
disp(:,j)=zeros(no_increments,1);
dispt(:,j)=zeros(no_increments,1);

Tperp(1,j)=0;
Tpar(1,j)=0;

for i=1:no_increments

    t(i,1)=time(i,1);

    if i==1

        [PR_u,PR_w,PR_l]=rootforce_disp(dispt(i,j),kappa,lambda,Wo,meanF_u,meanF_w,meanF_l,Fa,Fb,mF,kF,muF,sigF);

        Tperp(i,j)=0;
        Tpar(i,j)=0;

        ky(i,j)=(coh*L+(W*(1-kv)*cosd(slope)+Tperp(i,j)-Ub)*tand(phi)+Tpar(i,j)-W*(1-kv)*sind(slope))/(W*cosd(slope)+W*sind(slope)*tand(phi));
        
    else

    %Feedback between root resistance and Sliding Block Displacement
        [PR_u,PR_w,PR_l]=rootforce_disp(dispt(i-1,j),kappa,lambda,Wo,meanF_u,meanF_w,meanF_l,Fa,Fb,mF,kF,muF,sigF);

        Tperp(i,j)=0;%(PR_l/1000)*NR(j);
        Tpar(i,j)=(PR_l/1000)*NR(j);%0;
    
        ky(i,j)=(coh*L+(W*(1-kv)*cosd(slope)+Tperp(i,j)-Ub)*tand(phi)+Tpar(i,j)-W*(1-kv)*sind(slope))/(W*cosd(slope)+W*sind(slope)*tand(phi));
        accel(i,j)=kh(i,1)-ky(i,j);
        vel(i,j)=0.5*9.81*(accel(i,j)-accel(i-1,j))*time_increment+9.81*accel(i,j)*time_increment;
        if vel(i,j)<0
           vel(i,j)=0; 
        end
        disp(i,j)=0.5*(vel(i,j)-vel(i-1,j))*time_increment+vel(i,j)*time_increment;
        dispt(i,j)=disp(i,j)+dispt(i-1,j);
    
    end

end

figure(3);
subplot(3,1,1)
plot(t,dispt(:,j),'Color',color_test{j});
hold on
xlabel('Time [s]');
ylabel('Disp [m]');
grid on
xlim([0 time(end)])

subplot(3,1,2)
plot(t,ky(:,j),'Color',color_test{j});
hold on
xlabel('Time [s]');
ylabel('k_{y} [g]');
grid on
xlim([0 time(end)])

subplot(3,1,3)
plot(t,kh(:,1),'Color','k');
hold on
xlabel('Time [s]');
ylabel('k_{h} [g]');
grid on
ylim([-1 1])
xlim([0 time(end)])
toc

end